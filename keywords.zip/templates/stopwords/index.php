<?php include __DIR__ . '/../partials/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0">Stopwords</h1>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">Add stopword</h2>
        <form method="post" action="<?= e(url('/stopwords/add')) ?>">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
          <div class="input-group">
            <input class="form-control" name="word" placeholder="π.χ. το, στη, επίσης" required>
            <button class="btn btn-primary" type="submit">Add</button>
          </div>
        </form>
        <p class="text-muted small mt-2">Η λίστα εφαρμόζεται σε trendings/keywords extraction.</p>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-sm align-middle">
            <thead><tr><th>Word</th><th class="text-end">Actions</th></tr></thead>
            <tbody>
              <?php foreach ($rows as $r): ?>
                <tr>
                  <td><?= e($r['word']) ?></td>
                  <td class="text-end">
                    <form method="post" action="<?= e(url('/stopwords/delete')) ?>" class="d-inline">
                      <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                      <input type="hidden" name="word" value="<?= e($r['word']) ?>">
                      <button class="btn btn-sm btn-outline-danger" type="submit" onclick="return confirm('Delete stopword?')">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>
