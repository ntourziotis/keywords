<?php include __DIR__ . '/../partials/header.php'; ?>
<div class="row g-4">
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h2 class="h5 mb-0">Channel status</h2>
          <div class="d-flex gap-2 align-items-center">
            <form method="post" action="<?= e(url('/sync/run')) ?>" class="mb-0 d-flex gap-2 align-items-center">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Csrf::token()) ?>">
              <select name="channel_id" class="form-select form-select-sm" style="max-width: 220px">
                <option value="0">Sync all active</option>
                <?php foreach ($channels as $cc): ?>
                  <option value="<?= (int)$cc['id'] ?>"><?= e((string)$cc['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <input class="form-check-input" type="hidden" name="process" value="0">
              <div class="form-check mb-0">
                <input class="form-check-input" type="checkbox" name="process" value="1" id="syncProcess" checked>
                <label class="form-check-label small text-muted" for="syncProcess">Process</label>
              </div>
              <button class="btn btn-sm btn-success" type="submit">Sync now</button>
            </form>
            <a class="btn btn-sm btn-primary" href="<?= e(url('/channels')) ?>">Manage channels</a>
          </div>
        </div>
        <div class="table-responsive mt-3">
          <table class="table table-sm align-middle">
            <thead>
            <tr>
              <th>Channel</th>
              <th>Active</th>
              <th>News</th>
              <th>Poll (s)</th>
              <th>Last poll</th>
              <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($channels as $c): ?>
              <tr>
                <td><?= e($c['name']) ?></td>
                <td><?= (int)$c['active'] === 1 ? 'Yes' : 'No' ?></td>
                <td><?= (int)$c['is_news'] === 1 ? 'Yes' : 'No' ?></td>
                <td><?= (int)$c['poll_every_seconds'] ?></td>
                <td class="text-muted small"><?= e((string)($c['last_poll_at'] ?? '')) ?></td>
                <td><?= e((string)($c['last_poll_status'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="card shadow-sm mt-4">
      <div class="card-body">
        <h2 class="h5">Recent ingestion runs</h2>
        <div class="table-responsive">
          <table class="table table-sm">
            <thead>
            <tr>
              <th>Started</th>
              <th>Channel</th>
              <th>Seen</th>
              <th>New</th>
              <th>Updated</th>
              <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($logs as $l): ?>
              <tr>
                <td class="text-muted small"><?= e($l['started_at']) ?></td>
                <td><?= e($l['channel_name']) ?></td>
                <td><?= (int)$l['items_seen'] ?></td>
                <td><?= (int)$l['items_new'] ?></td>
                <td><?= (int)$l['items_updated'] ?></td>
                <td><?= e($l['status']) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h2 class="h5 mb-0">Global trendings (<?= (int)($_ENV['TRENDING_WINDOW_HOURS'] ?? 24) ?>h)</h2>
          <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/videos')) ?>">Videos</a>
        </div>
        <ol class="mt-3 mb-0">
          <?php foreach ($trendings as $t): ?>
            <li class="mb-1">
              <span><?= e($t['term']) ?></span>
              <span class="badge text-bg-secondary ms-2"><?= (int)$t['count'] ?></span>
            </li>
          <?php endforeach; ?>
        </ol>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
