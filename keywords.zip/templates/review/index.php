<?php include __DIR__ . '/../partials/header.php'; ?>

<?php
  $fmt = function($s) {
    if (!$s) return '';
    try { $dt = new DateTime((string)$s); return $dt->format('d/m/Y H:i'); } catch (Exception $e) { return (string)$s; }
  };

  $total = 0;
  foreach (($groups ?? []) as $cat => $subs) {
    foreach ($subs as $sub => $items) $total += count($items);
  }
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0">Review</h1>
  <div class="text-muted small">Needs review: <?= (int)$total ?></div>
</div>

<?php if (!empty($_SESSION['flash'])): ?>
  <div class="alert alert-info"><?= htmlspecialchars((string)$_SESSION['flash'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
  <?php unset($_SESSION['flash']); ?>
<?php endif; ?>

<?php if (empty($groups)): ?>
  <div class="alert alert-success">Nothing to review 🎉</div>
<?php else: ?>

<div class="accordion" id="reviewAcc">
<?php $i = 0; foreach ($groups as $catName => $subs): $i++; ?>
  <?php
    $catCount = 0;
    foreach ($subs as $subName => $items) $catCount += count($items);
    $catId = 'cat' . $i;
  ?>
  <div class="accordion-item">
    <h2 class="accordion-header" id="h<?= $catId ?>">
      <button class="accordion-button <?= $i === 1 ? '' : 'collapsed' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#c<?= $catId ?>" aria-expanded="<?= $i === 1 ? 'true' : 'false' ?>" aria-controls="c<?= $catId ?>">
        <strong class="me-2"><?= htmlspecialchars($catName, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></strong>
        <span class="badge text-bg-secondary"><?= (int)$catCount ?></span>
      </button>
    </h2>
    <div id="c<?= $catId ?>" class="accordion-collapse collapse <?= $i === 1 ? 'show' : '' ?>" aria-labelledby="h<?= $catId ?>" data-bs-parent="#reviewAcc">
      <div class="accordion-body">
        <div class="d-flex justify-content-end align-items-center gap-2 mb-2 flex-wrap">
          <form method="post" action="<?= htmlspecialchars(url('/review/backfill_subcategory'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" class="d-inline">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
            <input type="hidden" name="category" value="<?= htmlspecialchars($catName, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
            <input type="hidden" name="limit" value="500">
            <button class="btn btn-sm btn-outline-primary" onclick="return confirm('Backfill missing subcategory in category: <?= addslashes($catName) ?> ?');">Backfill subcategory</button>
          </form>

          <form method="post" action="<?= htmlspecialchars(url('/review/approve_category'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" class="d-inline">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
            <input type="hidden" name="category" value="<?= htmlspecialchars($catName, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
            <input type="hidden" name="limit" value="2000">
            <button class="btn btn-sm btn-outline-success" onclick="return confirm('Approve ALL in category: <?= addslashes($catName) ?> ?');">Approve category</button>
          </form>
        </div>

        <?php foreach ($subs as $subName => $items): ?>
          <div class="d-flex justify-content-between align-items-center mt-3">
            <h3 class="h6 mb-0">
              <span class="text-muted">Sub:</span>
              <?= htmlspecialchars($subName, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
            </h3>
            <div class="d-flex align-items-center gap-2">
              <span class="badge text-bg-light"><?= count($items) ?></span>
              <?php
                $ids = array_map(fn($x) => (int)$x['id'], $items);
                $idsStr = implode(',', $ids);
              ?>
              <form method="post" action="<?= htmlspecialchars(url('/review/approve_bulk'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" class="d-inline">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
                <input type="hidden" name="ids" value="<?= htmlspecialchars($idsStr, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
                <button class="btn btn-sm btn-outline-success" onclick="return confirm('Approve ALL in this group?')">Approve all</button>
              </form>
            </div>
          </div>

          <div class="table-responsive mt-2">
            <table class="table table-sm align-middle">
              <thead>
                <tr>
                  <th style="width:70px">ID</th>
                  <th>Title</th>
                  <th style="width:120px">Publish</th>
                  <th style="width:90px">Conf</th>
                  <th style="width:210px">Actions</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($items as $v): ?>
                <tr>
                  <td class="text-muted">#<?= (int)$v['id'] ?></td>
                  <td>
                    <div class="fw-semibold"><?= htmlspecialchars((string)$v['title_raw'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
                    <div class="small text-muted">
                      Channel: <?= (int)($v['channel_id'] ?? 0) ?>
                    </div>
                  </td>
                  <td class="text-muted small"><?= htmlspecialchars($fmt($v['publish_date'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></td>
                  <td><span class="badge text-bg-warning"><?= number_format((float)($v['confidence'] ?? 0), 2) ?></span></td>
                  <td>
                    <form method="post" action="<?= htmlspecialchars(url('/review/approve'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" class="d-inline">
                      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">
                      <input type="hidden" name="id" value="<?= (int)$v['id'] ?>">
                      <button class="btn btn-sm btn-success">Approve</button>
                    </form>
                    <a class="btn btn-sm btn-outline-primary" href="<?= htmlspecialchars(url('/videos/edit', ['id' => (int)$v['id']]), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>">Edit</a>
                    <a class="btn btn-sm btn-outline-secondary" href="/watch.php?id=<?= (int)$v['id'] ?>">Watch</a>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
<?php endforeach; ?>
</div>

<?php endif; ?>

<?php include __DIR__ . '/../partials/footer.php'; ?>
