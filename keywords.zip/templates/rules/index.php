<?php include __DIR__ . '/../partials/header.php'; ?>

<?php
  // quick helper for JSON dump
  function j($v): string { return htmlspecialchars(json_encode($v, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
?>

<?php
  $rows = $result['rows'] ?? ($rules ?? []);
  $pages = (int)($result['pages'] ?? 1);
  $total = (int)($result['total'] ?? count($rows));
  $cur = (int)($result['page'] ?? 1);
  $per = (int)($result['per_page'] ?? ($per ?? 50));
  $qsBase = $_GET;
  unset($qsBase['page'], $qsBase['r']);
  $pageUrl = function(int $page) use ($qsBase, $per): string {
    return url('/rules', array_merge($qsBase, ['page' => $page, 'per' => $per]));
  };
?>


<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0">Taxonomy Rules</h1>
  <div class="d-flex align-items-center gap-3">
    <div class="text-muted small">Rules classify videos automatically (TitleProcessor → taxonomy_rules)</div>
    <form method="get" action="<?= e($_ENV['APP_ENTRYPOINT'] ?? '/app.php') ?>" class="d-flex align-items-center gap-2">
      <input type="hidden" name="r" value="/rules">
      <?php foreach ($_GET as $k => $v): ?>
        <?php if (in_array((string)$k, ['r','page','per'], true)) continue; ?>
        <input type="hidden" name="<?= e((string)$k) ?>" value="<?= e((string)$v) ?>">
      <?php endforeach; ?>
      <span class="small text-muted">Per page</span>
      <select name="per" class="form-select form-select-sm" style="width:auto" onchange="this.form.submit()">
        <?php foreach ([25,50,100] as $pp): ?>
          <option value="<?= $pp ?>" <?= (int)$per === $pp ? 'selected' : '' ?>><?= $pp ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card shadow-sm mb-3">
      <div class="card-body">
        <h2 class="h6">Create rule</h2>
        <form method="post" action="<?= e(url('/rules/create')) ?>">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">

          <div class="mb-2">
            <label class="form-label">Name</label>
            <input class="form-control" name="name" required>
          </div>

          <div class="mb-2">
            <label class="form-label">Match type</label>
            <select class="form-select" name="match_type">
              <option value="regex" selected>regex</option>
              <option value="contains">contains</option>
            </select>
            <div class="form-text">Matching is performed on normalized lowercase titles (greek tonos removed).</div>
          </div>

          <div class="mb-2">
            <label class="form-label">Pattern</label>
            <input class="form-control" name="pattern" placeholder="e.g. (καιρος|κακοκαιρ|βροχ)" required>
          </div>

          <div class="mb-2">
            <label class="form-label">Category</label>
            <select class="form-select" name="category_id">
              <option value="">(no category)</option>
              <?php foreach ($categories as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-2">
            <label class="form-label">Subcategory</label>
            <select class="form-select" name="subcategory_id">
              <option value="">(no subcategory)</option>
              <?php foreach ($categories as $c): ?>
                <?php $catId = (int)$c['id']; $subs = $subcatsByCat[$catId] ?? []; ?>
                <?php if ($subs): ?>
                  <optgroup label="<?= e($c['name']) ?>">
                    <?php foreach ($subs as $s): ?>
                      <option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                  </optgroup>
                <?php endif; ?>
              <?php endforeach; ?>
            </select>
            <div class="form-text">Tip: you can set only Category (broad) or Category+Subcategory (precise).</div>
          </div>

          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Confidence</label>
              <input class="form-control" type="number" name="confidence" step="0.01" value="0.70" min="0" max="1">
            </div>
            <div class="col-6">
              <label class="form-label">Weight</label>
              <input class="form-control" type="number" name="priority" value="100">
            </div>
          </div>

          <div class="form-check form-switch mt-3">
            <input class="form-check-input" type="checkbox" role="switch" id="active" name="active" checked>
            <label class="form-check-label" for="active">Active</label>
          </div>

          <input type="hidden" name="source" value="manual">

          <button class="btn btn-primary mt-3" type="submit">Create</button>
        </form>
      </div>
    </div>

    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">Test classification</h2>
        <form method="get" action="<?= e(url('/rules')) ?>" class="mb-2">
          <div class="input-group">
            <input class="form-control" name="test_title" value="<?= e((string)$test_title) ?>" placeholder="Paste a video title...">
            <button class="btn btn-outline-primary" type="submit">Test</button>
          </div>
        </form>

        <?php if (!empty($test_result)): ?>
          <div class="small">
            <div><strong>Result</strong></div>
            <div>category_id: <code><?= e((string)($test_result['category_id'] ?? '')) ?></code></div>
            <div>subcategory_id: <code><?= e((string)($test_result['subcategory_id'] ?? '')) ?></code></div>
            <div>confidence: <code><?= e((string)($test_result['confidence'] ?? '')) ?></code></div>
            <div>status: <code><?= e((string)($test_result['status'] ?? '')) ?></code></div>
            <?php if (!empty($test_result['_rule']['rule'])): ?>
              <div class="mt-2"><strong>Matched rule</strong></div>
              <div class="text-muted"><?= e((string)($test_result['_rule']['rule']['name'] ?? '')) ?></div>
              <div class="text-muted">pattern: <code><?= e((string)($test_result['_rule']['rule']['pattern'] ?? '')) ?></code></div>
              <div class="text-muted">matched: <code><?= e((string)($test_result['_rule']['matched_text'] ?? '')) ?></code></div>
            <?php else: ?>
              <div class="mt-2 text-muted">No rule matched (fallback used).</div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="card shadow-sm mt-3">
      <div class="card-body">
        <h2 class="h6">Backfill (apply rules to existing videos)</h2>
        <form method="post" action="<?= e(url('/rules/backfill')) ?>">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Mode</label>
              <select class="form-select" name="mode">
                <option value="missing_subcategory" selected>Missing subcategory</option>
                <option value="missing_any">Missing category or subcategory</option>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label">Limit</label>
              <input class="form-control" type="number" name="limit" value="200" min="50" max="2000">
            </div>
          </div>
          <button class="btn btn-outline-primary mt-3" type="submit" onclick="return confirm('Run backfill now?')">Run backfill</button>
          <div class="form-text">Run multiple times if you have many videos.</div>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">Rules list</h2>
        <div class="table-responsive">
          <table class="table table-sm align-middle">
            <thead>
              <tr>
                <th style="width:60px">ID</th>
                <th>Name</th>
                <th>Type</th>
                <th>Pattern</th>
                <th>Target</th>
                <th style="width:90px">Conf</th>
                <th style="width:90px">Prio</th>
                <th style="width:80px">Active</th>
                <th class="text-end" style="width:180px">Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><?= (int)$r['id'] ?></td>
                <td>
                  <form method="post" action="<?= e(url('/rules/update')) ?>" class="d-flex gap-2">
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input class="form-control form-control-sm" name="name" value="<?= e((string)$r['name']) ?>">
                </td>
                <td style="width:110px">
                    <select class="form-select form-select-sm" name="match_type">
                      <option value="regex" <?= (string)$r['match_type']==='regex'?'selected':'' ?>>regex</option>
                      <option value="contains" <?= (string)$r['match_type']==='contains'?'selected':'' ?>>contains</option>
                    </select>
                </td>
                <td style="min-width:240px">
                    <input class="form-control form-control-sm" name="pattern" value="<?= e((string)$r['pattern']) ?>">
                </td>
                <td style="min-width:220px">
                    <select class="form-select form-select-sm mb-1" name="category_id">
                      <option value="">(no category)</option>
                      <?php foreach ($categories as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (int)($r['category_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                      <?php endforeach; ?>
                    </select>
                    <select class="form-select form-select-sm" name="subcategory_id">
                      <option value="">(no subcategory)</option>
                      <?php foreach ($subcatsByCat as $catId => $subs): ?>
                        <?php foreach ($subs as $s): ?>
                          <option value="<?= (int)$s['id'] ?>" <?= (int)($r['subcategory_id'] ?? 0) === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                      <?php endforeach; ?>
                    </select>
                </td>
                <td>
                    <input class="form-control form-control-sm" type="number" step="0.01" min="0" max="1" name="confidence" value="<?= e((string)$r['confidence']) ?>">
                </td>
                <td>
                    <input class="form-control form-control-sm" type="number" name="priority" value="<?= e((string)$r['priority']) ?>">
                </td>
                <td class="text-center">
                    <input class="form-check-input" type="checkbox" name="active" <?= (int)$r['active'] === 1 ? 'checked' : '' ?>>
                    <input type="hidden" name="source" value="<?= e((string)($r['source'] ?? 'manual')) ?>">
                </td>
                <td class="text-end">
                    <button class="btn btn-sm btn-outline-primary" type="submit">Save</button>
                  </form>
                  <form method="post" action="<?= e(url('/rules/delete')) ?>" class="d-inline">
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger" type="submit" onclick="return confirm('Delete rule?')">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-2">
          <div class="small text-muted">Total: <?= (int)$total ?> · Page <?= (int)$cur ?>/<?= (int)$pages ?></div>
          <?php if ($pages > 1): ?>
          <nav aria-label="Rules pagination">
            <ul class="pagination pagination-sm mb-0">
              <li class="page-item <?= $cur <= 1 ? 'disabled' : '' ?>">
                <a class="page-link" href="<?= e($pageUrl(max(1, $cur-1))) ?>">Prev</a>
              </li>
              <?php
                $start = max(1, $cur - 3);
                $end = min($pages, $cur + 3);
                if ($start > 1) { $start = 1; $end = min($pages, 7); }
                if ($end < $pages && ($end - $start) < 6) { $start = max(1, $pages - 6); $end = $pages; }
              ?>
              <?php for ($p = $start; $p <= $end; $p++): ?>
                <li class="page-item <?= $p === $cur ? 'active' : '' ?>">
                  <a class="page-link" href="<?= e($pageUrl($p)) ?>"><?= (int)$p ?></a>
                </li>
              <?php endfor; ?>
              <li class="page-item <?= $cur >= $pages ? 'disabled' : '' ?>">
                <a class="page-link" href="<?= e($pageUrl(min($pages, $cur+1))) ?>">Next</a>
              </li>
            </ul>
          </nav>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>