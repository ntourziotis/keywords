<?php include __DIR__ . '/../partials/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0">Errors (unresolved)</h1>
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-sm align-middle">
        <thead>
          <tr>
            <th>Date</th>
            <th>Context</th>
            <th>Ref</th>
            <th>Message</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="text-muted small"><?= e($r['created_at']) ?></td>
              <td><?= e($r['context']) ?></td>
              <td class="text-muted small"><?= e((string)($r['ref_id'] ?? '')) ?></td>
              <td style="min-width: 420px;">
                <div><?= e($r['message']) ?></div>
                <?php if (!empty($r['trace'])): ?>
                  <details class="mt-1"><summary class="text-muted small">Trace</summary>
                    <pre class="small mb-0"><?= e((string)$r['trace']) ?></pre>
                  </details>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <form method="post" action="<?= e(url('/errors/resolve')) ?>" class="d-inline">
                  <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="btn btn-sm btn-success" type="submit">Resolve</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
