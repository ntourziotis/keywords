<?php include __DIR__ . '/../partials/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0">Channels</h1>
  <a class="btn btn-primary" href="<?= e(url('/channels/new')) ?>">Add channel</a>
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-sm align-middle">
        <thead>
        <tr>
          <th>Name</th>
          <th>MRSS URL</th>
          <th>Active</th>
          <th>News</th>
          <th>Poll (s)</th>
          <th>Last poll</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($channels as $c): ?>
          <tr>
            <td><strong><?= e($c['name']) ?></strong></td>
            <td class="text-muted small" style="max-width: 520px; word-break: break-all;"><?= e($c['source_url']) ?></td>
            <td><?= (int)$c['active'] === 1 ? 'Yes' : 'No' ?></td>
            <td><?= (int)$c['is_news'] === 1 ? 'Yes' : 'No' ?></td>
            <td><?= (int)$c['poll_every_seconds'] ?></td>
            <td class="text-muted small"><?= e((string)($c['last_poll_at'] ?? '')) ?></td>
            <td><?= e((string)($c['last_poll_status'] ?? '')) ?></td>
            <td class="text-end">
              <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/channels/edit', ['id' => (int)$c['id']])) ?>">Edit</a>
              <form method="post" action="<?= e(url('/channels/delete')) ?>" class="d-inline">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                <button class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete channel?')" type="submit">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
