<?php include __DIR__ . '/../partials/header.php'; ?>
<?php
  $isEdit = ($mode ?? 'create') === 'edit';
  $action = $isEdit ? '/channels/update?id=' . (int)$channel['id'] : '/channels';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0"><?= $isEdit ? 'Edit channel' : 'Add channel' ?></h1>
  <a class="btn btn-outline-secondary" href="<?= e(url('/channels')) ?>">Back</a>
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <form method="post" action="<?= e($action) ?>">
      <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Channel name</label>
          <input class="form-control" name="name" required value="<?= e((string)($channel['name'] ?? '')) ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Poll every (seconds)</label>
          <input class="form-control" type="number" min="10" step="1" name="poll_every_seconds" value="<?= e((string)($channel['poll_every_seconds'] ?? 60)) ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Connatix MRSS Export URL</label>
          <input class="form-control" name="source_url" required value="<?= e((string)($channel['source_url'] ?? '')) ?>" placeholder="https://mi.connatix.com/.../mrss">
        </div>
        <div class="col-12">
          <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" role="switch" id="is_news" name="is_news" <?= ((int)($channel['is_news'] ?? 1) === 1) ? 'checked' : '' ?>>
            <label class="form-check-label" for="is_news">Treat as News feed</label>
          </div>
          <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" role="switch" id="active" name="active" <?= ((int)($channel['active'] ?? 1) === 1) ? 'checked' : '' ?>>
            <label class="form-check-label" for="active">Active</label>
          </div>
        </div>
      </div>
      <div class="mt-3">
        <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Create channel' ?></button>
      </div>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
