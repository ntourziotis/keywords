<?php include __DIR__ . '/../partials/header.php'; ?>

<?php
  $types = ['category' => 'Categories', 'subcategory' => 'Subcategories', 'show' => 'Shows', 'country' => 'Countries'];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0">Taxonomy</h1>
  <form method="post" action="<?= e(url('/taxonomy/dedupe')) ?>" class="d-inline">
    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
    <input type="hidden" name="type" value="<?= e($type) ?>">
    <button class="btn btn-sm btn-outline-secondary" type="submit" onclick="return confirm('Fix duplicates & enforce uniqueness?')">Fix duplicates</button>
  </form>
</div>

<ul class="nav nav-tabs mb-3">
  <?php foreach ($types as $t => $label): ?>
    <li class="nav-item"><a class="nav-link <?= $type === $t ? 'active' : '' ?>" href="<?= e(url('/taxonomy', ['type' => $t])) ?>"><?= e($label) ?></a></li>
  <?php endforeach; ?>
</ul>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">Create</h2>
        <form method="post" action="<?= e(url('/taxonomy/create')) ?>">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
          <input type="hidden" name="type" value="<?= e($type) ?>">

          <?php if ($type === 'subcategory'): ?>
            <div class="mb-2">
              <label class="form-label">Parent category</label>
              <select name="parent_id" class="form-select" required>
                <option value="">Select...</option>
                <?php foreach ($categories as $c): ?>
                  <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          <?php else: ?>
            <input type="hidden" name="parent_id" value="">
          <?php endif; ?>

          <div class="mb-2">
            <label class="form-label">Name</label>
            <input class="form-control" name="name" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Sort</label>
            <input class="form-control" type="number" name="sort" value="0">
          </div>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" role="switch" id="active" name="active" checked>
            <label class="form-check-label" for="active">Active</label>
          </div>
          <button class="btn btn-primary" type="submit">Create</button>
        </form>
      </div>
    </div>

    <div class="alert alert-info mt-3">
      <div class="small">
        <strong>Tip:</strong> For bulk imports (full taxonomy lists), edit <code>db/schema_sqlite.sql</code> or add a JSON import script.
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">List</h2>
        <div class="table-responsive">
          <table class="table table-sm align-middle">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Parent</th>
                <th>Sort</th>
                <th>Active</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><?= (int)$r['id'] ?></td>
                <td>
                  <form method="post" action="<?= e(url('/taxonomy/update')) ?>" class="d-flex gap-2">
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="type" value="<?= e($type) ?>">
                    <input class="form-control form-control-sm" name="name" value="<?= e($r['name']) ?>">
                </td>
                <td class="text-muted small"><?= e((string)($r['parent_id'] ?? '')) ?></td>
                <td style="width:120px"><input class="form-control form-control-sm" type="number" name="sort" value="<?= (int)$r['sort'] ?>"></td>
                <td style="width:90px">
                  <input class="form-check-input" type="checkbox" name="active" <?= (int)$r['active'] === 1 ? 'checked' : '' ?>>
                </td>
                <td class="text-end" style="width:200px">
                    <button class="btn btn-sm btn-outline-primary" type="submit">Save</button>
                  </form>
                  <form method="post" action="<?= e(url('/taxonomy/delete')) ?>" class="d-inline">
                    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                    <input type="hidden" name="type" value="<?= e($type) ?>">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger" type="submit" onclick="return confirm('Delete item?')">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>
