<?php
use App\Auth\AuthService;

$u = AuthService::user();

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

// NO-REWRITE friendly entrypoint (defaults to /app.php)
$ENTRYPOINT = $_ENV['APP_ENTRYPOINT'] ?? '/app.php';

/**
 * Build an application URL in "no rewrite" mode.
 * Example: url('/videos', ['page'=>2]) -> /app.php?r=/videos&page=2
 */
function url(string $path, array $query = []): string {
  $ENTRYPOINT = $_ENV['APP_ENTRYPOINT'] ?? '/app.php';
  if ($path === '' || $path[0] !== '/') $path = '/' . ltrim($path, '/');
  $params = array_merge(['r' => $path], $query);
  return $ENTRYPOINT . '?' . http_build_query($params);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($_ENV['APP_NAME'] ?? 'Keywords Dashboard') ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= e(url('/')) ?>">Keywords</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav" aria-controls="nav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <?php if ($u): ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('/videos')) ?>">Videos</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('/channels')) ?>">Channels</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('/stopwords')) ?>">Stopwords</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('/taxonomy')) ?>">Taxonomy</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('/rules')) ?>">Rules</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('/review')) ?>">Review</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('/errors')) ?>">Errors</a></li>
        <?php endif; ?>
      </ul>
      <div class="d-flex align-items-center gap-3">
        <?php if ($u): ?>
          <span class="text-light small"><?= e((string)$u['email']) ?> (<?= e((string)$u['role']) ?>)</span>
          <form method="post" action="<?= e(url('/logout')) ?>" class="mb-0">
            <input type="hidden" name="csrf" value="<?= e(\App\Core\Csrf::token()) ?>">
            <button class="btn btn-outline-light btn-sm" type="submit">Logout</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<main class="container-fluid py-4">
  <?php if (!empty($_SESSION['flash'])): ?>
    <div class="alert alert-info"><?= e((string)$_SESSION['flash']) ?></div>
    <?php unset($_SESSION['flash']); ?>
  <?php endif; ?>
