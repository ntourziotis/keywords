<?php include __DIR__ . '/../partials/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h1 class="h4 mb-0">Edit video</h1>
    <div class="text-muted small">Media ID: <?= e($video['media_id']) ?> | Channel: <?= e($video['channel_name'] ?? '') ?></div>
  </div>
  <a class="btn btn-outline-secondary" href="<?= e(url('/videos')) ?>">Back to list</a>
</div>

<div class="card shadow-sm mb-3">
  <div class="card-body">
    <h2 class="h6">Title</h2>
    <div class="p-2 bg-light border rounded"><?= e($video['title_raw']) ?></div>
    <div class="text-muted small mt-2">Publish: <?= e((string)($video['publish_date'] ?? '')) ?> | Status: <?= e((string)($video['status'] ?? '')) ?> | Confidence: <?= e((string)($video['confidence'] ?? '')) ?></div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6 mb-3">Manual taxonomy override</h2>
        <form method="post" action="<?= e(url('/videos/update', ['id' => (int)$video['id']])) ?>">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">

          <div class="mb-3">
            <label class="form-label">Category</label>
            <select class="form-select" name="category_id">
              <option value="">(none)</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= (int)$cat['id'] ?>" <?= (string)$video['category_id'] === (string)$cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Subcategory</label>
            <select class="form-select" name="subcategory_id">
              <option value="">(none)</option>
              <?php foreach ($subcategories as $sub): ?>
                <option value="<?= (int)$sub['id'] ?>" <?= (string)$video['subcategory_id'] === (string)$sub['id'] ? 'selected' : '' ?>><?= e($sub['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="form-text">(MVP) Subcategories list is based on current saved category.</div>
          </div>

          <div class="mb-3">
            <label class="form-label">Show</label>
            <select class="form-select" name="show_id">
              <option value="">(none)</option>
              <?php foreach ($shows as $sh): ?>
                <option value="<?= (int)$sh['id'] ?>" <?= (string)$video['show_id'] === (string)$sh['id'] ? 'selected' : '' ?>><?= e($sh['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Country</label>
            <select class="form-select" name="country_id">
              <option value="">(none)</option>
              <?php foreach ($countries as $co): ?>
                <option value="<?= (int)$co['id'] ?>" <?= (string)$video['country_id'] === (string)$co['id'] ? 'selected' : '' ?>><?= e($co['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <button class="btn btn-primary" type="submit">Save (manual)</button>
        </form>

        <hr>

        <form method="post" action="<?= e(url('/videos/delete')) ?>" onsubmit="return confirm('Delete video from DB?')">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
          <input type="hidden" name="id" value="<?= (int)$video['id'] ?>">
          <button class="btn btn-outline-danger" type="submit">Delete video</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">Extracted entities</h2>

        <div class="mb-3">
          <div class="text-muted small">Persons</div>
          <?php if (empty($persons)): ?>
            <div class="text-muted">—</div>
          <?php else: ?>
            <div><?= e(implode(', ', $persons)) ?></div>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <div class="text-muted small">Teams</div>
          <?php if (empty($teams)): ?>
            <div class="text-muted">—</div>
          <?php else: ?>
            <div><?= e(implode(', ', $teams)) ?></div>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <div class="text-muted small">Trendings</div>
          <?php if (empty($trendings)): ?>
            <div class="text-muted">—</div>
          <?php else: ?>
            <div><?= e(implode(', ', $trendings)) ?></div>
          <?php endif; ?>
        </div>

        <hr>
        <h2 class="h6">Export</h2>
        <p class="text-muted small mb-1">If you set <code>EXPORT_TOKEN</code> in <code>.env</code>, you can generate an enriched MRSS feed that includes <code>&lt;media:keywords&gt;</code> for Connatix/JWP import.</p>
        <div class="small">
          <code>/export/mrss?token=YOUR_TOKEN&amp;channel_id=<?= (int)$video['channel_id'] ?>&amp;limit=200</code>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>
