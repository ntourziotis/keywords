<?php include __DIR__ . '/../partials/header.php'; ?>

<?php
  $rows = $result['rows'] ?? [];
  $pages = (int)($result['pages'] ?? 1);
  $total = (int)($result['total'] ?? 0);
  $cur = (int)($result['page'] ?? 1);

  // Build safe pagination URLs (no-rewrite compatible)
  $qsBase = $_GET;
  unset($qsBase['page'], $qsBase['r']);
  $pageUrl = function(int $page) use ($qsBase): string {
    return url('/videos', array_merge($qsBase, ['page' => $page]));
  };

  $selectedChannel = (string)($filters['channel_id'] ?? '');
  $selectedStatus  = (string)($filters['status'] ?? '');
  $selectedCat     = (string)($filters['category_id'] ?? '');
  $selectedSort    = (string)($filters['sort'] ?? 'publish_desc');
  $q               = (string)($filters['q'] ?? '');


  $fmt = function($s) {
    $s = is_string($s) ? trim($s) : '';
    if ($s === '') return '';
    try {
      $dt = new DateTime($s);
      return $dt->format('d/m/Y H:i');
    } catch (Exception $e) {
      return (string)$s;
    }
  };
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 mb-0">Videos</h1>
  <div class="text-muted small">Total: <?= $total ?></div>
</div>

<div class="card shadow-sm mb-3">
  <div class="card-body">
    <form method="get" action="<?= e($_ENV['APP_ENTRYPOINT'] ?? '/app.php') ?>" class="row g-2 align-items-end">
      <input type="hidden" name="r" value="/videos">
      <div class="col-md-3">
        <label class="form-label">Channel</label>
        <select name="channel_id" class="form-select">
          <option value="">All</option>
          <?php foreach ($channels as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= $selectedChannel === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-2">
        <label class="form-label">Status</label>
        <select name="status" class="form-select">
          <option value="">All</option>
          <?php foreach (['auto','manual','needs_review'] as $st): ?>
            <option value="<?= e($st) ?>" <?= $selectedStatus === $st ? 'selected' : '' ?>><?= e($st) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-3">
        <label class="form-label">Category</label>
        <select name="category_id" class="form-select">
          <option value="">All</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= (int)$cat['id'] ?>" <?= $selectedCat === (string)$cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-2">
        <label class="form-label">Sort</label>
        <select name="sort" class="form-select">
          <?php
            $sortOptions = [
              'publish_desc'  => 'Publish (latest)',
              'publish_asc'   => 'Publish (oldest)',
              'ingested_desc' => 'Ingested (latest)',
              'ingested_asc'  => 'Ingested (oldest)',
              'id_desc'       => 'ID (newest)',
              'id_asc'        => 'ID (oldest)',
            ];
          ?>
          <?php foreach ($sortOptions as $key => $label): ?>
            <option value="<?= e($key) ?>" <?= $selectedSort === $key ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-3">
        <label class="form-label">Search title</label>
        <input name="q" class="form-control" value="<?= e($q) ?>" placeholder="π.χ. VAR, Καιρός, Κώτσηρας">
      </div>

      <div class="col-md-1">
        <button class="btn btn-primary w-100" type="submit">Go</button>
      </div>

      <div class="col-md-2">
        <label class="form-label">Per page</label>
        <select name="per" class="form-select">
          <?php foreach ([25,50,100] as $pp): ?>
            <option value="<?= $pp ?>" <?= (int)$per === $pp ? 'selected' : '' ?>><?= $pp ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </form>
  </div>
</div>

<form method="post" action="<?= e(url('/videos/bulk')) ?>">
  <input type="hidden" name="csrf" value="<?= e($csrf) ?>">

  <div class="card shadow-sm">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div class="d-flex align-items-center gap-2">
          <button class="btn btn-sm btn-outline-secondary" type="button" onclick="toggleAll(true)">Select all</button>
          <button class="btn btn-sm btn-outline-secondary" type="button" onclick="toggleAll(false)">Clear</button>
        </div>
        <div class="text-muted small">Page <?= $cur ?> / <?= max(1,$pages) ?></div>
      </div>

      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th style="width:36px"></th>
              <th>Publish</th>
              <th>Ingested</th>
              <th>Watch</th>
              <th>Channel</th>
              <th>Title</th>
              <th>Category</th>
              <th>Subcategory</th>
              <th>Status</th>
              <th class="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><input class="form-check-input" type="checkbox" name="ids[]" value="<?= (int)$r['id'] ?>"></td>
                <td class="text-muted small"><?= e($fmt((string)($r['publish_date'] ?? ''))) ?></td>
                <td class="text-muted small"><?= e($fmt($r['ingested_at'] ?? ($r['created_at'] ?? ($r['updated_at'] ?? '')))) ?></td>
                <td><a class="btn btn-sm btn-outline-success" target="_blank" rel="noopener" href="<?= e('/watch.php?id=' . (int)$r['id']) ?>">Watch</a></td>
                <td><?= e($r['channel_name'] ?? '') ?></td>
                <td style="min-width: 340px;">
                  <div><strong><?= e($r['title_raw']) ?></strong></div>
                  <div class="text-muted small">Media ID: <?= e($r['media_id']) ?></div>
                </td>
                <td><?= e((string)($r['category_name'] ?? '')) ?></td>
                <td><?= e((string)($r['subcategory_name'] ?? '')) ?></td>
                <td>
                  <span class="badge <?= ($r['status'] ?? '') === 'needs_review' ? 'text-bg-warning' : 'text-bg-secondary' ?>">
                    <?= e((string)($r['status'] ?? '')) ?>
                  </span>
                </td>
                <td class="text-end">
                  <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/videos/edit', ['id' => (int)$r['id']])) ?>">Edit</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="row g-2 mt-3">
        <div class="col-md-3">
          <label class="form-label">Bulk set category</label>
          <select name="category_id" class="form-select">
            <option value="">(no change)</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= (int)$cat['id'] ?>"><?= e($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Subcategory shown in edit screen (depends on category).</div>
        </div>
        <div class="col-md-3">
          <label class="form-label">Bulk subcategory id</label>
          <input class="form-control" name="subcategory_id" placeholder="optional numeric id">
          <div class="form-text">MVP: use per-video edit for accurate subcategory selection.</div>
        </div>
        <div class="col-md-3">
          <label class="form-label">Bulk show id</label>
          <input class="form-control" name="show_id" placeholder="optional numeric id">
        </div>
        <div class="col-md-3">
          <label class="form-label">Bulk country id</label>
          <input class="form-control" name="country_id" placeholder="optional numeric id">
        </div>

        <div class="col-12">
          <button class="btn btn-success" type="submit" onclick="return confirm('Apply bulk changes to selected videos?')">Apply bulk update</button>
        </div>
      </div>
    </div>
  </div>
</form>

<nav class="mt-3" aria-label="pagination">
  <ul class="pagination">
    <?php $prev = max(1, $cur - 1); $next = min($pages, $cur + 1); ?>
    <li class="page-item <?= $cur <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($pageUrl($prev)) ?>">Prev</a></li>
    <li class="page-item disabled"><span class="page-link">Page <?= $cur ?> / <?= max(1,$pages) ?></span></li>
    <li class="page-item <?= $cur >= $pages ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($pageUrl($next)) ?>">Next</a></li>
  </ul>
</nav>

<script>
function toggleAll(on) {
  document.querySelectorAll('input[name="ids[]"]').forEach(cb => cb.checked = !!on);
}
</script>

<?php include __DIR__ . '/../partials/footer.php'; ?>