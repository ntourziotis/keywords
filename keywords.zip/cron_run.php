<?php
require_once __DIR__ . '/endpoints/cron_run.php';
