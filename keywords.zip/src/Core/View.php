<?php

declare(strict_types=1);

namespace App\Core;

final class View
{
    public static function render(string $template, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        $base = dirname(__DIR__, 2) . '/templates';
        $file = $base . '/' . ltrim($template, '/');
        if (!str_ends_with($file, '.php')) {
            $file .= '.php';
        }

        if (!file_exists($file)) {
            throw new \RuntimeException('Template not found: ' . $file);
        }

        require $file;
    }
}
