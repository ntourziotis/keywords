<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

final class DB
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $connection = Config::get('DB_CONNECTION', 'sqlite');

        if ($connection === 'sqlite') {
            $dbPath = Config::get('DB_DATABASE', './db/app.sqlite');
            // Resolve relative path from project root
            if (!str_starts_with($dbPath, '/')) {
                $dbPath = dirname(__DIR__, 2) . '/' . ltrim($dbPath, './');
            }
            $dir = dirname($dbPath);
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }
            $dsn = 'sqlite:' . $dbPath;
            $pdo = new PDO($dsn);
            // Improve concurrency & reduce "database is locked" errors.
            // These are best-effort and safe to ignore if unsupported.
            try { $pdo->setAttribute(PDO::ATTR_TIMEOUT, 5); } catch (\Throwable $e) { /* ignore */ }
            try { $pdo->exec('PRAGMA busy_timeout=5000'); } catch (\Throwable $e) { /* ignore */ }
            try { $pdo->exec('PRAGMA journal_mode=WAL'); } catch (\Throwable $e) { /* ignore */ }
        } else {
            $host = Config::get('DB_HOST', '127.0.0.1');
            $port = Config::get('DB_PORT', '3306');
            $db   = Config::get('DB_DATABASE', 'keywords');
            $user = Config::get('DB_USERNAME', 'root');
            $pass = Config::get('DB_PASSWORD', '');
            $charset = 'utf8mb4';
            $dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";
            $pdo = new PDO($dsn, $user, $pass);
        }

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

        // Best-effort: enforce root-level taxonomy uniqueness (SQLite UNIQUE allows multiple NULLs).
        if ($connection === 'sqlite') {
            try {
                $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_taxonomy_unique_expr ON taxonomy(type, COALESCE(parent_id,0), name)');
            } catch (\Throwable $e) {
                // If duplicates already exist, the index creation will fail.
                // Admin can click "Fix duplicates" in Taxonomy to resolve.
            }
        }

        self::$pdo = $pdo;
        return self::$pdo;
    }
}
