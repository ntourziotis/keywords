<?php

declare(strict_types=1);

namespace App\Core;

final class Logger
{
    private static ?SimpleLogger $log = null;

    public static function get(): SimpleLogger
    {
        if (self::$log) {
            return self::$log;
        }

        $logPath = dirname(__DIR__, 2) . '/storage/logs/app.log';
        if (!is_dir(dirname($logPath))) {
            @mkdir(dirname($logPath), 0775, true);
        }

        self::$log = new SimpleLogger($logPath);
        return self::$log;
    }
}

final class SimpleLogger
{
    public function __construct(private string $file) {}

    public function info(string $message, array $context = []): void
    {
        $this->write('INFO', $message, $context);
    }

    public function error(string $message, array $context = []): void
    {
        $this->write('ERROR', $message, $context);
    }

    private function write(string $level, string $message, array $context = []): void
    {
        $ts = date('Y-m-d H:i:s');
        $ctx = $context ? ' ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
        $line = sprintf("[%s] %s %s%s\n", $ts, $level, $message, $ctx);
        @file_put_contents($this->file, $line, FILE_APPEND);
    }
}
