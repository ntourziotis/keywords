<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\DB;
use App\Models\Stopword;
use App\Models\Taxonomy;
use App\Models\TaxonomyRule;

final class TitleProcessor
{
    private array $stop;

    public function __construct()
    {
        $this->stop = Stopword::listAsSet();
    }

    /**
     * Main classifier.
     * Goal: keep false positives low BUT drastically reduce needs_review by providing safe fallbacks.
     *
     * @return array{title_clean:string,category_id:?int,subcategory_id:?int,show_id:?int,country_id:?int,confidence:float,status:string,trendings:array<int,string>}
     */
    public function process(string $title): array
    {
        $clean = $this->cleanTitle($title);
        $tokens = $this->tokenize($clean);
        $norm = $this->normalize($clean);

        $categoryId = null;
        $subcategoryId = null;
        $showId = null;
        $countryId = null;

        $confidence = 0.40;
        $status = 'auto';

        // -------------------------
        // RULE-BASED *SCORING* CLASSIFIER (taxonomy_rules)
        // -------------------------
        // Pseudo-ML: aggregate multiple matching rules into category/subcategory scores.
        $writeTh = (float)\App\Core\Config::get('CLASSIFIER_WRITE_THRESHOLD', '0.85');
        $reviewTh = (float)\App\Core\Config::get('CLASSIFIER_REVIEW_THRESHOLD', '0.60');
        $minCatScore = (float)\App\Core\Config::get('CLASSIFIER_MIN_CAT_SCORE', '4.0');

        $scored = TaxonomyRule::scoreMatch($norm);
        $bestCat = $scored['category_id'] ?? null;
        $bestSub = $scored['subcategory_id'] ?? null;
        $conf = (float)($scored['confidence'] ?? 0.0);

        // Extract top category score (absolute) for a sanity gate.
        $catScores = (array)($scored['breakdown']['category_scores'] ?? []);
        $topCatScore = 0.0;
        if (!empty($catScores)) {
            $vals = array_values($catScores);
            $topCatScore = (float)($vals[0] ?? 0.0);
        }

        if ($bestCat !== null && $topCatScore >= $minCatScore) {
            $categoryId = (int)$bestCat;
            $subcategoryId = $bestSub !== null ? (int)$bestSub : null;
            $confidence = $conf;

            if ($confidence >= $writeTh) {
                $status = 'auto';
            } elseif ($confidence >= $reviewTh) {
                $status = 'needs_review';
            } else {
                // Keep the category signal but require review.
                $status = 'needs_review';
                $subcategoryId = null;
                $confidence = min($confidence, 0.55);
            }
        }
// SAFE FALLBACK (reduce needs_review)
        // -------------------------
        if ($categoryId === null) {
            // Default most TV feeds to News if no clear signal.
            $categoryId = $this->ensureTax('category', 'News');
            // Optional "general" subcategory if you create one
            $subcategoryId = $this->ensureSubIfExists($categoryId, 'General');
            $confidence = 0.50;
            $status = 'needs_review';
        }

        // Optional: set show/country automatically for high-confidence News
        $newsId = Taxonomy::findId('category', 'News');
        if ($newsId && $categoryId === $newsId && $confidence >= 0.80) {
            $showId = $this->ensureTax('show', 'Ειδήσεις');
            $countryId = $this->ensureTax('country', 'Ελλάδα');
        }

        // Status decision: only flag needs_review when confidence is really low
        if ($confidence < 0.50) {
            $status = 'needs_review';
        }

        return [
            'title_clean' => $clean,
            'category_id' => $categoryId,
            'subcategory_id' => $subcategoryId,
            'show_id' => $showId,
            'country_id' => $countryId,
            'confidence' => $confidence,
            'status' => $status,
            'trendings' => $this->extractTrendings($tokens),
        ];
    }

    private function cleanTitle(string $title): string
    {
        $t = trim(preg_replace('/\s+/u', ' ', $title) ?? $title);
        return str_replace(["\t"], ' ', $t);
    }

    /**
     * Normalize text for rule matching:
     * - lowercase
     * - remove greek tonos/diacritics
     * - collapse whitespace
     */
    private function normalize(string $text): string
    {
        $t = mb_strtolower($text);
        // strip greek tonos (most common)
        $map = [
            'ά' => 'α', 'έ' => 'ε', 'ή' => 'η', 'ί' => 'ι', 'ό' => 'ο', 'ύ' => 'υ', 'ώ' => 'ω',
            'ϊ' => 'ι', 'ΐ' => 'ι', 'ϋ' => 'υ', 'ΰ' => 'υ',
            'Ά' => 'α', 'Έ' => 'ε', 'Ή' => 'η', 'Ί' => 'ι', 'Ό' => 'ο', 'Ύ' => 'υ', 'Ώ' => 'ω',
        ];
        $t = strtr($t, $map);
        $t = preg_replace('/\s+/u', ' ', $t) ?? $t;
        return trim($t);
    }

    /** @return array<int,string> */
    private function tokenize(string $text): array
    {
        $parts = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($text), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $out = [];
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p === '' || isset($this->stop[$p])) continue;
            if (mb_strlen($p) < 2) continue;
            $out[] = $p;
        }
        return $out;
    }

    private function containsAny(string $haystack, array $needles): bool
    {
        foreach ($needles as $n) {
            if ($n !== '' && str_contains($haystack, $n)) return true;
        }
        return false;
    }

    private function ensureTax(string $type, string $name): ?int
    {
        $row = Taxonomy::findByTypeAndName($type, $name);
        if ($row) return (int)$row['id'];

        // create if missing
        $id = Taxonomy::upsert($type, $name, null, 0, 1);
        return $id ?: null;
    }

    /** @return array{0:?int,1:?int} */
    private function ensureCategorySub(string $categoryName, string $subcategoryName): array
    {
        $catId = $this->ensureTax('category', $categoryName);
        $subId = null;

        if ($catId) {
            $stmt = DB::pdo()->prepare(
                "SELECT id FROM taxonomy WHERE type = :t AND parent_id = :p AND name = :n LIMIT 1"
            );
            $stmt->execute([':t' => 'subcategory', ':p' => $catId, ':n' => $subcategoryName]);
            $row = $stmt->fetch();
            if ($row && isset($row['id'])) {
                $subId = (int)$row['id'];
            } else {
                // create if missing
                $subId = Taxonomy::upsert('subcategory', $subcategoryName, $catId, 0, 1) ?: null;
            }
        }

        return [$catId, $subId];
    }

    private function ensureSubIfExists(?int $categoryId, string $subcategoryName): ?int
    {
        if (!$categoryId) return null;

        $stmt = DB::pdo()->prepare(
            "SELECT id FROM taxonomy WHERE type = :t AND parent_id = :p AND name = :n LIMIT 1"
        );
        $stmt->execute([':t' => 'subcategory', ':p' => $categoryId, ':n' => $subcategoryName]);
        $row = $stmt->fetch();
        return ($row && isset($row['id'])) ? (int)$row['id'] : null;
    }

    /** @return array<int,string> */
    private function extractTrendings(array $tokens): array
    {
        $counts = [];
        foreach ($tokens as $tok) $counts[$tok] = ($counts[$tok] ?? 0) + 1;
        arsort($counts);
        return array_slice(array_keys($counts), 0, 6);
    }
}
