<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Config;

final class MrssFetcher
{
    /**
     * Fetch MRSS feed items.
     *
     * Returned keys are a superset so the caller can persist more fields when supported:
     * - media_id (string)   : stable ID (prefer <guid>)
     * - title (string)
     * - publish_date (?string) : normalized Y-m-d H:i:s (UTC) if possible
     * - video_url (?string) : best playable MP4 URL (prefer <enclosure url>, else best <media:content url>)
     * - thumbnail (?string) : <media:thumbnail url>
     * - page_url (?string)  : <link> if present
     * - duration (?int)     : seconds (from media:content duration)
     * - description (?string) : <description> text if present
     *
     * @return array<int, array{
     *   media_id:string,
     *   title:string,
     *   publish_date:?string,
     *   video_url?:?string,
     *   thumbnail?:?string,
     *   page_url?:?string,
     *   duration?:?int,
     *   description?:?string
     * }>
     */
    public function fetch(string $url): array
    {
        // Connatix (and some other providers) paginate MRSS via <cnx:link rel="next" href="..."/>
        // If we only fetch the first page, we may miss items (or repeatedly see the same limited window).
        $maxPages = (int)Config::get('MRSS_MAX_PAGES', '10');
        $maxItems = (int)Config::get('MRSS_MAX_ITEMS', '2000');

        $all = [];
        $seenIds = [];

        $nextUrl = $url;
        $page = 0;
        while ($nextUrl !== '' && $page < $maxPages && count($all) < $maxItems) {
            $page++;

            // Avoid loops
            $key = strtolower(trim($nextUrl));
            if ($key === '' || isset($seenIds['_url:' . $key])) {
                break;
            }
            $seenIds['_url:' . $key] = true;

            $xmlString = $this->httpGet($nextUrl);
            if ($xmlString === '') {
                break;
            }

            // Try XML parsing first
            $items = $this->parseXml($xmlString);
            if (empty($items)) {
                // Fallback: regex parsing (handles hosts without SimpleXML/libxml quirks)
                $items = $this->parseRegex($xmlString);
            }

            foreach ($items as $row) {
                $mid = (string)($row['media_id'] ?? '');
                if ($mid === '') continue;
                if (isset($seenIds[$mid])) continue;
                $seenIds[$mid] = true;
                $all[] = $row;
                if (count($all) >= $maxItems) {
                    break;
                }
            }

            // Find next page URL (if any)
            $nextUrl = $this->extractNextUrl($xmlString);
        }

        return $all;
    }

    /**
     * Extract MRSS next-page URL.
     * Supports Connatix style: <cnx:link rel="next" href="..."/>
     */
    private function extractNextUrl(string $xmlString): string
    {
        $prev = libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xmlString, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);

        if ($xml && isset($xml->channel)) {
            $ns = $xml->getNamespaces(true);
            if (isset($ns['cnx'])) {
                $cnx = $xml->channel->children($ns['cnx']);
                if (isset($cnx->link)) {
                    foreach ($cnx->link as $lnk) {
                        $attrs = $lnk->attributes();
                        if (!$attrs) continue;
                        $rel = isset($attrs['rel']) ? (string)$attrs['rel'] : '';
                        if (strtolower($rel) !== 'next') continue;
                        $href = isset($attrs['href']) ? trim((string)$attrs['href']) : '';
                        if ($href !== '') return $href;
                    }
                }
            }
        }

        // regex fallback
        if (preg_match('~<cnx:link\b[^>]*\brel=["\']next["\'][^>]*\bhref=["\']([^"\']+)["\']~i', $xmlString, $m)) {
            return trim((string)$m[1]);
        }

        return '';
    }

    /** @return array<int, array<string,mixed>> */
    private function parseXml(string $xmlString): array
    {
        $prev = libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xmlString, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);

        if (!$xml) {
            return [];
        }

        $ns = $xml->getNamespaces(true);

        // RSS: <rss><channel><item>...</item></channel></rss>
        $channel = $xml->channel ?? null;
        if (!$channel) {
            return [];
        }

        $out = [];
        $items = $channel->item ?? [];
        foreach ($items as $item) {
            $title = trim((string)($item->title ?? ''));
            if ($title === '') continue;

            $guid = trim((string)($item->guid ?? ''));
            if ($guid === '' && isset($item->id)) {
                $guid = trim((string)$item->id);
            }

            $pubRaw = (string)($item->pubDate ?? '');
            if ($pubRaw === '' && isset($ns['dc'])) {
                $dc = $item->children($ns['dc']);
                $pubRaw = (string)($dc->date ?? '');
            }
            $pub = $this->normalizeDate($pubRaw);

            $pageUrl = trim((string)($item->link ?? ''));

            $desc = trim((string)($item->description ?? ''));

            // enclosure url (best signal)
            $videoUrl = '';
            if (isset($item->enclosure)) {
                $encAttrs = $item->enclosure->attributes();
                if ($encAttrs && isset($encAttrs['url'])) {
                    $videoUrl = (string)$encAttrs['url'];
                }
            }

            $thumb = '';
            $duration = null;
            $mediaUrls = [];

            // media namespace
            if (isset($ns['media'])) {
                $media = $item->children($ns['media']);

                // <media:thumbnail url="..."/>
                if (isset($media->thumbnail)) {
                    $tAttrs = $media->thumbnail->attributes();
                    if ($tAttrs && isset($tAttrs['url'])) {
                        $thumb = (string)$tAttrs['url'];
                    }
                }

                // <media:group><media:content .../></media:group> OR <media:content .../>
                if (isset($media->group)) {
                    foreach ($media->group->children($ns['media'])->content as $content) {
                        $attrs = $content->attributes();
                        if ($attrs && isset($attrs['url'])) {
                            $mediaUrls[] = [
                                'url' => (string)$attrs['url'],
                                'height' => isset($attrs['height']) ? (int)$attrs['height'] : 0,
                                'duration' => isset($attrs['duration']) ? (int)$attrs['duration'] : null,
                            ];
                        }
                    }
                }

                if (isset($media->content)) {
                    // SimpleXML may treat it as list or single element
                    foreach ($media->content as $content) {
                        $attrs = $content->attributes();
                        if ($attrs && isset($attrs['url'])) {
                            $mediaUrls[] = [
                                'url' => (string)$attrs['url'],
                                'height' => isset($attrs['height']) ? (int)$attrs['height'] : 0,
                                'duration' => isset($attrs['duration']) ? (int)$attrs['duration'] : null,
                            ];
                        }
                    }
                }
            }

            // pick duration from any media:content duration
            foreach ($mediaUrls as $mu) {
                if ($mu['duration'] !== null && $mu['duration'] > 0) {
                    $duration = (int)$mu['duration'];
                    break;
                }
            }

            // if no enclosure, pick best media:content by height (fallback to first)
            if ($videoUrl === '' && !empty($mediaUrls)) {
                usort($mediaUrls, function ($a, $b) {
                    return ($b['height'] <=> $a['height']);
                });
                $videoUrl = (string)($mediaUrls[0]['url'] ?? '');
            }

            $mediaId = $guid !== '' ? $guid : ($videoUrl !== '' ? $videoUrl : hash('sha1', $title . '|' . ($pub ?? '')));
            if (strlen($mediaId) > 255) {
                $mediaId = hash('sha1', $mediaId);
            }

            $row = [
                'media_id' => $mediaId,
                'title' => $title,
                'publish_date' => $pub,
            ];

            if ($videoUrl !== '') $row['video_url'] = $videoUrl;
            if ($thumb !== '') $row['thumbnail'] = $thumb;
            if ($pageUrl !== '') $row['page_url'] = $pageUrl;
            if ($duration !== null) $row['duration'] = $duration;
            if ($desc !== '') $row['description'] = $desc;

            $out[] = $row;
        }

        return $out;
    }

    /** @return array<int, array<string,mixed>> */
    private function parseRegex(string $xml): array
    {
        $out = [];
        if (!preg_match_all('~<item\\b[^>]*>(.*?)</item>~si', $xml, $m)) {
            return $out;
        }

        foreach ($m[1] as $block) {
            $title = '';
            if (preg_match('~<title\\b[^>]*>(.*?)</title>~si', $block, $mm)) $title = trim(strip_tags($mm[1]));
            if ($title === '') continue;

            $guid = '';
            if (preg_match('~<guid\\b[^>]*>(.*?)</guid>~si', $block, $mm)) $guid = trim(strip_tags($mm[1]));

            $pubRaw = '';
            if (preg_match('~<pubDate\\b[^>]*>(.*?)</pubDate>~si', $block, $mm)) $pubRaw = trim(strip_tags($mm[1]));
            $pub = $this->normalizeDate($pubRaw);

            $pageUrl = '';
            if (preg_match('~<link\\b[^>]*>(.*?)</link>~si', $block, $mm)) $pageUrl = trim(strip_tags($mm[1]));

            $desc = '';
            if (preg_match('~<description\\b[^>]*>(.*?)</description>~si', $block, $mm)) $desc = trim(strip_tags($mm[1]));

            $thumb = '';
            if (preg_match('~<media:thumbnail\\b[^>]*url="([^"]+)"~si', $block, $mm)) $thumb = trim($mm[1]);

            $videoUrl = '';
            if (preg_match('~<enclosure\\b[^>]*url="([^"]+)"~si', $block, $mm)) $videoUrl = trim($mm[1]);

            $duration = null;
            if (preg_match('~<media:content\\b[^>]*duration="(\\d+)"~si', $block, $mm)) $duration = (int)$mm[1];

            if ($videoUrl === '') {
                $urls = [];
                if (preg_match_all('~<media:content\\b[^>]*url="([^"]+)"~si', $block, $mm)) {
                    $urls = array_map('trim', $mm[1]);
                }
                if ($urls) {
                    // Prefer 1080/720 if present
                    foreach (['1080','720','360'] as $q) {
                        foreach ($urls as $u) {
                            if (strpos($u, "/{$q}_") !== false || strpos($u, "{$q}_h264") !== false) { $videoUrl = $u; break 2; }
                        }
                    }
                    if ($videoUrl === '') $videoUrl = $urls[0];
                }
            }

            $mediaId = $guid !== '' ? $guid : ($videoUrl !== '' ? $videoUrl : hash('sha1', $title . '|' . ($pub ?? '')));
            if (strlen($mediaId) > 255) {
                $mediaId = hash('sha1', $mediaId);
            }

            $row = [
                'media_id' => $mediaId,
                'title' => $title,
                'publish_date' => $pub,
            ];
            if ($videoUrl !== '') $row['video_url'] = $videoUrl;
            if ($thumb !== '') $row['thumbnail'] = $thumb;
            if ($pageUrl !== '') $row['page_url'] = $pageUrl;
            if ($duration !== null) $row['duration'] = $duration;
            if ($desc !== '') $row['description'] = $desc;

            $out[] = $row;
        }

        return $out;
    }

    private function httpGet(string $url): string
    {
        $timeout = (int)Config::get('http_timeout', '20');
        $ua = (string)Config::get('http_user_agent', 'KeywordsBot/1.0 (+https://keywords.adweb.gr)');

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 5,
                CURLOPT_CONNECTTIMEOUT => $timeout,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_USERAGENT => $ua,
                CURLOPT_HTTPHEADER => [
                    'Accept: application/xml,text/xml,*/*;q=0.9',
                    'Accept-Encoding: gzip,deflate',
                ],
                CURLOPT_ENCODING => '',
            ]);
            $body = curl_exec($ch);
            curl_close($ch);
            return is_string($body) ? $body : '';
        }

        // fallback if cURL unavailable
        $ctx = stream_context_create([
            'http' => ['timeout' => $timeout, 'user_agent' => $ua],
            'https' => ['timeout' => $timeout, 'user_agent' => $ua],
        ]);
        $body = @file_get_contents($url, false, $ctx);
        return is_string($body) ? $body : '';
    }

    private function normalizeDate(string $raw): ?string
    {
        $raw = trim($raw);
        if ($raw === '') return null;

        // Common RSS: "Tue, 06 May 2025 08:06:52 GMT"
        $ts = strtotime($raw);
        if ($ts !== false) {
            // store as UTC datetime string
            return gmdate('Y-m-d H:i:s', $ts);
        }

        return null;
    }
}
