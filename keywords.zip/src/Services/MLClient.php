<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Config;

final class MLClient
{
    /**
     * @return array<string,mixed>|null
     */
    public static function predict(string $titleRaw, ?int $channelId = null): ?array
    {
        if (!Config::getBool('ML_ENABLED', true)) {
            return null;
        }

        $base = rtrim((string)Config::get('ML_SERVICE_URL', 'http://127.0.0.1:8010'), '/');
        if ($base === '') {
            return null;
        }

        $payload = ['title' => $titleRaw];
        if ($channelId) {
            $payload['channel_id'] = $channelId;
        }

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return null;
        }

        $ch = curl_init($base . '/predict');
        if (!$ch) return null;

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_CONNECTTIMEOUT => 1,
            CURLOPT_TIMEOUT => 2,
        ]);

        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($resp === false || $code < 200 || $code >= 300) {
            return null;
        }

        $arr = json_decode((string)$resp, true);
        return is_array($arr) ? $arr : null;
    }

    public static function writeThreshold(): float
    {
        return (float)Config::get('ML_WRITE_THRESHOLD', '0.85');
    }

    public static function reviewThreshold(): float
    {
        return (float)Config::get('ML_REVIEW_THRESHOLD', '0.60');
    }
}
