<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Stopword;
use App\Models\TaxonomyRule;
use PDOException;

/**
 * Creates lightweight "contains" rules from manual edits to reduce future gaps.
 */
final class RuleTrainer
{
    /**
     * @return int number of rules created
     */
    public static function trainFromManual(string $titleRaw, int $categoryId, ?int $subcategoryId): int
    {
        if ($categoryId <= 0) {
            return 0;
        }

        $normTitle = self::normalize($titleRaw);
        $tokens = self::tokens($normTitle);

        if (!$tokens) {
            return 0;
        }

        $created = 0;

        // pick a couple of strong tokens
        $picked = [];
        foreach ($tokens as $tok) {
            if (mb_strlen($tok) < 4) continue;
            if (preg_match('/^\d+$/u', $tok)) continue;
            $picked[] = $tok;
            if (count($picked) >= 2) break;
        }

        // phrase rule (2-token) is stronger
        if (count($picked) >= 2) {
            $created += self::tryCreate([
                'name' => 'learned: ' . $picked[0] . ' ' . $picked[1],
                'match_type' => 'contains',
                'pattern' => $picked[0] . ' ' . $picked[1],
                'category_id' => $categoryId,
                'subcategory_id' => $subcategoryId,
                'confidence' => 0.86,
                'priority' => 260,
                'active' => 1,
                'source' => 'learned',
            ]);
        }

        // single-token rules (weaker)
        foreach (array_unique($picked) as $tok) {
            $created += self::tryCreate([
                'name' => 'learned: ' . $tok,
                'match_type' => 'contains',
                'pattern' => $tok,
                'category_id' => $categoryId,
                'subcategory_id' => $subcategoryId,
                'confidence' => 0.74,
                'priority' => 220,
                'active' => 1,
                'source' => 'learned',
            ]);
        }

        return $created;
    }

    /** @param array<string,mixed> $data */
    private static function tryCreate(array $data): int
    {
        try {
            TaxonomyRule::create($data);
            return 1;
        } catch (PDOException $e) {
            // ignore duplicates (unique constraint)
            return 0;
        }
    }

    private static function normalize(string $text): string
    {
        $t = mb_strtolower($text);
        $map = [
            'ά' => 'α', 'έ' => 'ε', 'ή' => 'η', 'ί' => 'ι', 'ό' => 'ο', 'ύ' => 'υ', 'ώ' => 'ω',
            'ϊ' => 'ι', 'ΐ' => 'ι', 'ϋ' => 'υ', 'ΰ' => 'υ',
            'Ά' => 'α', 'Έ' => 'ε', 'Ή' => 'η', 'Ί' => 'ι', 'Ό' => 'ο', 'Ύ' => 'υ', 'Ώ' => 'ω',
        ];
        $t = strtr($t, $map);
        // keep punctuation for phrase matching but normalize spaces
        $t = preg_replace('/\s+/u', ' ', $t) ?? $t;
        return trim($t);
    }

    /** @return array<int,string> */
    private static function tokens(string $normalizedTitle): array
    {
        $stop = Stopword::listAsSet();
        $parts = preg_split('/[^\p{L}\p{N}]+/u', $normalizedTitle, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $out = [];
        foreach ($parts as $p) {
            $p = trim((string)$p);
            if ($p === '') continue;
            if (isset($stop[$p])) continue;
            if (mb_strlen($p) < 2) continue;
            $out[] = $p;
        }
        return $out;
    }
}
