<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Stopword;
use App\Models\TrendingTerm;
use App\Core\DB;

final class TrendingService
{
    public function compute(int $hours = 24): void
    {
        $pdo = DB::pdo();
        $since = date('Y-m-d H:i:s', time() - ($hours * 3600));
        $stop = Stopword::listAsSet();
        $topN = (int)($_ENV['TRENDING_TOP_N'] ?? 15);

        // Global
        $stmt = $pdo->prepare('SELECT title_raw FROM videos WHERE publish_date IS NULL OR publish_date >= :since');
        $stmt->execute([':since' => $since]);
        $rows = $stmt->fetchAll();

        $counts = [];
        foreach ($rows as $r) {
            foreach ($this->extractTerms((string)$r['title_raw'], $stop) as $term) {
                $counts[$term] = ($counts[$term] ?? 0) + 1;
            }
        }
        arsort($counts);
        $slice = array_slice($counts, 0, $topN, true);
        $terms = [];
        foreach ($slice as $t => $c) {
            $terms[] = ['term' => $t, 'count' => (int)$c];
        }
        TrendingTerm::replaceScope('global', null, $hours, $terms);

        // Per channel
        $chanStmt = $pdo->query('SELECT id FROM channels WHERE active=1');
        foreach ($chanStmt->fetchAll() as $cRow) {
            $channelId = (int)$cRow['id'];
            $stmt = $pdo->prepare('SELECT title_raw FROM videos WHERE channel_id=:cid AND (publish_date IS NULL OR publish_date >= :since)');
            $stmt->execute([':cid' => $channelId, ':since' => $since]);
            $rows = $stmt->fetchAll();

            $counts = [];
            foreach ($rows as $r) {
                foreach ($this->extractTerms((string)$r['title_raw'], $stop) as $term) {
                    $counts[$term] = ($counts[$term] ?? 0) + 1;
                }
            }
            arsort($counts);
            $slice = array_slice($counts, 0, $topN, true);
            $terms = [];
            foreach ($slice as $t => $cnt) {
                $terms[] = ['term' => $t, 'count' => (int)$cnt];
            }
            TrendingTerm::replaceScope('channel', $channelId, $hours, $terms);
        }
    }

    /**
     * @return string[]
     */
    private function extractTerms(string $title, array $stopSet): array
    {
        $t = mb_strtolower($title);
        $t = preg_replace('/[\[\]{}()"“”‘’`´]/u', ' ', $t);
        $t = preg_replace('/[^\p{L}\p{N}\s\-]+/u', ' ', $t);
        $t = preg_replace('/\s+/u', ' ', $t);
        $t = trim($t);

        $parts = preg_split('/\s+/u', $t) ?: [];
        $out = [];
        foreach ($parts as $p) {
            $p = trim($p, "- ");
            if ($p === '' || mb_strlen($p) < 3) {
                continue;
            }
            if (isset($stopSet[$p])) {
                continue;
            }
            if (preg_match('/^\d+$/u', $p)) {
                continue;
            }
            $out[] = $p;
        }
        return array_values(array_unique($out));
    }
}
