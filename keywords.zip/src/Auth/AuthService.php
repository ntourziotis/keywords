<?php

declare(strict_types=1);

namespace App\Auth;

use App\Models\User;

final class AuthService
{
    public static function startSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            $name = $_ENV['SESSION_NAME'] ?? 'adweb_keywords';
            session_name($name);
            session_start();
        }
    }

    public static function attempt(string $email, string $password): bool
    {
        self::startSession();
        $user = User::findByEmail(trim(strtolower($email)));
        if (!$user) {
            return false;
        }
        if (!password_verify($password, $user['password_hash'])) {
            return false;
        }
        $_SESSION['uid'] = (int)$user['id'];
        return true;
    }

    public static function logout(): void
    {
        self::startSession();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                (bool)$params['secure'],
                (bool)$params['httponly']
            );
        }
        session_destroy();
    }

    public static function user(): ?array
    {
        self::startSession();
        $uid = $_SESSION['uid'] ?? null;
        if (!$uid) {
            return null;
        }
        return User::findById((int)$uid);
    }

    /**
     * Redirect to login in a way that works with NO-REWRITE setups.
     * We always redirect to /login.php (physical file) which then forwards to /app.php?r=/login.
     */
    private static function redirectToLogin(): void
    {
        header('Location: /login.php', true, 302);
        exit;
    }

    public static function requireLogin(): void
    {
        if (!self::user()) {
            self::redirectToLogin();
        }
    }

    public static function requireRole(string $role): void
    {
        $u = self::user();
        if (!$u) {
            self::redirectToLogin();
        }
        if (($u['role'] ?? '') !== $role) {
            http_response_code(403);
            echo '403 Forbidden';
            exit;
        }
    }
}
