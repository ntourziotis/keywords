<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Csrf;
use App\Core\View;
use App\Models\Channel;

final class ChannelsController
{
    /**
     * NO-REWRITE friendly redirect.
     * Builds /app.php?r=/route (entrypoint configurable via APP_ENTRYPOINT).
     */
    private static function redirectTo(string $path, array $query = []): void
    {
        $entry = $_ENV['APP_ENTRYPOINT'] ?? '/app.php';
        if ($path === '' || $path[0] !== '/') {
            $path = '/' . ltrim($path, '/');
        }
        $params = array_merge(['r' => $path], $query);
        header('Location: ' . $entry . '?' . http_build_query($params));
        exit;
    }

    public static function index(): void
    {
        AuthService::requireLogin();
        $channels = Channel::all();
        View::render('channels/index', ['channels' => $channels, 'csrf' => Csrf::token()]);
    }

    public static function createForm(): void
    {
        AuthService::requireLogin();
        View::render('channels/form', ['mode' => 'create', 'channel' => null, 'csrf' => Csrf::token()]);
    }

    public static function store(): void
    {
        AuthService::requireLogin();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }
        $data = [
            'name' => trim((string)($_POST['name'] ?? '')),
            'source_url' => trim((string)($_POST['source_url'] ?? '')),
            'source_type' => 'mrss',
            'is_news' => isset($_POST['is_news']) ? 1 : 0,
            'poll_every_seconds' => (int)($_POST['poll_every_seconds'] ?? 60),
            'active' => isset($_POST['active']) ? 1 : 0,
        ];
        if ($data['name'] === '' || $data['source_url'] === '') {
            $_SESSION['flash'] = 'Name and MRSS URL are required.';
            self::redirectTo('/channels/new');
        }
        Channel::create($data);
        $_SESSION['flash'] = 'Channel created.';
        self::redirectTo('/channels');
    }

    public static function editForm(): void
    {
        AuthService::requireLogin();
        $id = (int)($_GET['id'] ?? 0);
        $channel = $id ? Channel::find($id) : null;
        if (!$channel) {
            http_response_code(404);
            echo 'Not found';
            exit;
        }
        View::render('channels/form', ['mode' => 'edit', 'channel' => $channel, 'csrf' => Csrf::token()]);
    }

    public static function update(): void
    {
        AuthService::requireLogin();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }
        $id = (int)($_GET['id'] ?? 0);
        $channel = $id ? Channel::find($id) : null;
        if (!$channel) {
            http_response_code(404);
            echo 'Not found';
            exit;
        }
        $data = [
            'name' => trim((string)($_POST['name'] ?? '')),
            'source_url' => trim((string)($_POST['source_url'] ?? '')),
            'source_type' => 'mrss',
            'is_news' => isset($_POST['is_news']) ? 1 : 0,
            'poll_every_seconds' => (int)($_POST['poll_every_seconds'] ?? 60),
            'active' => isset($_POST['active']) ? 1 : 0,
        ];
        Channel::update($id, $data);
        $_SESSION['flash'] = 'Channel updated.';
        self::redirectTo('/channels');
    }

    public static function delete(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            Channel::delete($id);
            $_SESSION['flash'] = 'Channel deleted.';
        }
        self::redirectTo('/channels');
    }
}
