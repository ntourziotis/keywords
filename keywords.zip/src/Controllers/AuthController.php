<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Config;
use App\Core\Csrf;
use App\Core\View;

final class AuthController
{
    private static function entrypoint(): string
    {
        return Config::get('APP_ENTRYPOINT', '/app.php');
    }

    public static function showLogin(): void
    {
        AuthService::startSession();
        if (AuthService::user()) {
            header('Location: ' . self::entrypoint() . '?r=%2F');
            exit;
        }
        View::render('auth/login', ['csrf' => Csrf::token(), 'error' => null]);
    }

    public static function login(): void
    {
        AuthService::startSession();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $email = (string)($_POST['email'] ?? '');
        $pass  = (string)($_POST['password'] ?? '');

        if (AuthService::attempt($email, $pass)) {
            header('Location: ' . self::entrypoint() . '?r=%2F');
            exit;
        }

        View::render('auth/login', ['csrf' => Csrf::token(), 'error' => 'Λάθος στοιχεία σύνδεσης.']);
    }

    public static function logout(): void
    {
        AuthService::startSession();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        AuthService::logout();
        header('Location: ' . self::entrypoint() . '?r=%2Flogin');
        exit;
    }
}
