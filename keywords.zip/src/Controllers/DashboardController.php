<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\View;
use App\Models\Channel;
use App\Models\IngestLog;
use App\Models\TrendingTerm;

final class DashboardController
{
    public static function index(): void
    {
        AuthService::requireLogin();
        $user = AuthService::user();
        $channels = Channel::all();
        $logs = IngestLog::recent(20);
        $trendings = TrendingTerm::top('global', null, (int)($_ENV['TRENDING_WINDOW_HOURS'] ?? 24), (int)($_ENV['TRENDING_TOP_N'] ?? 15));
        View::render('dashboard/index', [
            'user' => $user,
            'channels' => $channels,
            'logs' => $logs,
            'trendings' => $trendings,
        ]);
    }
}
