<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Csrf;
use App\Core\View;
use App\Models\ErrorLog;

final class ErrorsController
{
    /**
     * NO-REWRITE friendly redirect.
     * Builds /app.php?r=/route (entrypoint configurable via APP_ENTRYPOINT).
     */
    private static function redirectTo(string $path, array $query = []): void
    {
        $entry = $_ENV['APP_ENTRYPOINT'] ?? '/app.php';
        if ($path === '' || $path[0] !== '/') {
            $path = '/' . ltrim($path, '/');
        }
        $params = array_merge(['r' => $path], $query);
        header('Location: ' . $entry . '?' . http_build_query($params));
        exit;
    }

    public static function index(): void
    {
        AuthService::requireLogin();
        $rows = ErrorLog::recent(200, false);
        View::render('errors/index', ['rows' => $rows, 'csrf' => Csrf::token()]);
    }

    public static function resolve(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            ErrorLog::resolve($id);
            $_SESSION['flash'] = 'Error marked as resolved.';
        }
        self::redirectTo('/errors');
    }
}
