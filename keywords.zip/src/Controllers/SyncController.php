<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Csrf;
use App\Models\Channel;
use App\Models\ErrorLog;
use App\Models\IngestLog;
use App\Models\Video;
use App\Services\MrssFetcher;
use App\Services\TitleProcessor;
use App\Services\TrendingService;

/**
 * Manual "Sync now" endpoint for the UI.
 * Runs a one-off ingest for all active channels or a single channel, ignoring poll timing.
 */
final class SyncController
{
    private static function entry(): string
    {
        return (string)($_ENV['APP_ENTRYPOINT'] ?? '/app.php');
    }

    private static function redirect(string $route): void
    {
        if ($route === '' || $route[0] !== '/') {
            $route = '/' . ltrim($route, '/');
        }
        header('Location: ' . self::entry() . '?r=' . $route, true, 302);
        exit;
    }

    public static function run(): void
    {
        AuthService::requireRole('admin');

        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            return;
        }

        $channelId = (int)($_POST['channel_id'] ?? 0);
        $doProcess = (int)($_POST['process'] ?? 1) === 1;

        $channels = [];
        if ($channelId > 0) {
            $c = Channel::find($channelId);
            if ($c) {
                $channels = [$c];
            }
        } else {
            $channels = Channel::allActive();
        }

        if (!$channels) {
            $_SESSION['flash'] = 'No channels to sync.';
            self::redirect('/');
        }

        $fetcher = new MrssFetcher();
        $processor = new TitleProcessor();

        $totSeen = 0;
        $totNew = 0;
        $totUpd = 0;

        foreach ($channels as $c) {
            $cid = (int)$c['id'];
            $logId = IngestLog::start($cid);

            try {
                $items = $fetcher->fetch((string)$c['source_url']);
                $seen = count($items);
                $new = 0;
                $upd = 0;

                foreach ($items as $item) {
                    $mediaId = (string)($item['media_id'] ?? '');
                    if ($mediaId === '') {
                        continue;
                    }

                    $before = Video::findByChannelAndMedia($cid, $mediaId);

                    $extra = [];
                    if (isset($item['video_url'])) $extra['video_url'] = $item['video_url'];
                    if (isset($item['thumbnail'])) $extra['thumbnail'] = $item['thumbnail'];
                    if (isset($item['page_url'])) $extra['page_url'] = $item['page_url'];
                    if (isset($item['duration'])) $extra['duration'] = $item['duration'];
                    if (isset($item['description'])) $extra['description_raw'] = $item['description'];

                    $stored = Video::upsert(
                        $cid,
                        $mediaId,
                        $item['publish_date'] ?? null,
                        (string)($item['title'] ?? ''),
                        $extra
                    );

                    if (!$before) {
                        $new++;
                    } else {
                        // Count as updated when we actually changed/fill something meaningful
                        $changed = false;
                        foreach (['title_raw','publish_date','video_url','thumbnail','page_url','duration','description_raw'] as $k) {
                            $b = $before[$k] ?? null;
                            $a = $stored[$k] ?? null;
                            if ($b === null || $b === '' || $b === 0) {
                                if ($a !== null && $a !== '' && $a !== 0) {
                                    $changed = true;
                                    break;
                                }
                            }
                            if (is_string($b) && is_string($a) && $b !== $a) {
                                $changed = true;
                                break;
                            }
                            if (is_int($b) && is_int($a) && $b !== $a) {
                                $changed = true;
                                break;
                            }
                        }
                        if ($changed) {
                            $upd++;
                        }
                    }
                }

                Channel::touchPollStatus($cid, 'ok', null);
                IngestLog::finish($logId, [
                    'items_seen' => $seen,
                    'items_new' => $new,
                    'items_updated' => $upd,
                    'status' => 'ok',
                ]);

                $totSeen += $seen;
                $totNew += $new;
                $totUpd += $upd;

            } catch (\Throwable $e) {
                Channel::touchPollStatus($cid, 'error', $e->getMessage());
                IngestLog::finish($logId, [
                    'status' => 'error',
                    'message' => $e->getMessage(),
                ]);
                ErrorLog::create('sync', (string)$cid, $e->getMessage(), $e->getTraceAsString());
            }
        }

        $processed = 0;
        $needs = 0;

        if ($doProcess) {
            $batch = (int)($_ENV['PROCESS_BATCH'] ?? 200);
            if ($batch < 1) $batch = 200;
            if ($batch > 1000) $batch = 1000;

            $toProcess = Video::listForProcessing($batch);
            foreach ($toProcess as $v) {
                $vid = (int)$v['id'];
                try {
                    $res = $processor->process((string)$v['title_raw']);
                    Video::updateProcessing($vid, $res);
                    $processed++;
                } catch (\Throwable $e) {
                    Video::markNeedsReview($vid, $e->getMessage());
                    ErrorLog::create('process', (string)$vid, $e->getMessage(), $e->getTraceAsString());
                    $needs++;
                }
            }

            try {
                $tr = new TrendingService();
                $tr->compute((int)($_ENV['TRENDING_WINDOW_HOURS'] ?? 24));
            } catch (\Throwable $e) {
                ErrorLog::create('trendings', null, $e->getMessage(), $e->getTraceAsString());
            }
        }

        $msg = "Sync complete: seen={$totSeen}, new={$totNew}, updated={$totUpd}";
        if ($doProcess) {
            $msg .= ", processed={$processed}, needs_review={$needs}";
        }
        $_SESSION['flash'] = $msg;

        self::redirect('/');
    }
}
