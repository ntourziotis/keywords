<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Csrf;
use App\Core\View;
use App\Models\Taxonomy;
use App\Models\TaxonomyRule;
use App\Models\Video;
use App\Services\TitleProcessor;

final class RulesController
{
    public static function index(): void
    {
        AuthService::requireRole('admin');

        $page = max(1, (int)($_GET['page'] ?? 1));
        $per = (int)($_GET['per'] ?? 50);
        if (!in_array($per, [25,50,100], true)) { $per = 50; }

        $testTitle = trim((string)($_GET['test_title'] ?? ''));
        $testResult = null;
        if ($testTitle !== '') {
            $tp = new TitleProcessor();
            $testResult = $tp->process($testTitle);
            // also expose matching rule (debug)
            // We can't access the internal normalize directly, so we re-normalize here.
            $norm = self::normalizeText($testTitle);
            $testResult['_rule'] = TaxonomyRule::bestMatch($norm);
        }

        $result = TaxonomyRule::paginate(null, $page, $per);
        $rules = $result['rows'] ?? [];$categories = Taxonomy::categories();
        $subcatsByCat = [];
        foreach ($categories as $c) {
            $subcatsByCat[(int)$c['id']] = Taxonomy::subcategoriesByParent((int)$c['id']);
        }

        View::render('rules/index', [
            'csrf' => Csrf::token(),
            'rules' => $rules,
            'result' => $result,
            'per' => $per,
            'page' => $page,
            'categories' => $categories,
            'subcatsByCat' => $subcatsByCat,
            'test_title' => $testTitle,
            'test_result' => $testResult,
        ]);
    }

    public static function create(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $data = self::readRuleFromPost();
        if ($data['name'] === '' || $data['pattern'] === '') {
            $_SESSION['flash'] = 'Rule name and pattern are required.';
            header('Location: ' . self::u('/rules'));
            exit;
        }
        TaxonomyRule::create($data);
        $_SESSION['flash'] = 'Rule created.';
        header('Location: ' . self::u('/rules'));
        exit;
    }

    public static function update(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            http_response_code(400);
            echo 'Bad id';
            exit;
        }

        $data = self::readRuleFromPost();
        TaxonomyRule::update($id, $data);
        $_SESSION['flash'] = 'Rule updated.';
        header('Location: ' . self::u('/rules'));
        exit;
    }

    public static function delete(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            TaxonomyRule::delete($id);
            $_SESSION['flash'] = 'Rule deleted.';
        }
        header('Location: ' . self::u('/rules'));
        exit;
    }

    /**
     * Backfill missing taxonomy using current rules.
     * Runs in small batches to avoid timeouts.
     */
    public static function backfill(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $limit = (int)($_POST['limit'] ?? 200);
        if ($limit < 50) $limit = 50;
        if ($limit > 2000) $limit = 2000;

        $mode = (string)($_POST['mode'] ?? 'missing_subcategory');
        if (!in_array($mode, ['missing_subcategory', 'missing_any'], true)) {
            $mode = 'missing_subcategory';
        }

        $ids = Video::listIdsForBackfill($limit, $mode);
        $tp = new TitleProcessor();

        $updated = 0;
        foreach ($ids as $id) {
            $v = Video::find($id);
            if (!$v) continue;
            if (($v['status'] ?? '') === 'manual') continue;
            $res = $tp->process((string)($v['title_raw'] ?? ''));
            // only update if we actually got a better subcategory/category
            $fields = [
                'title_clean' => $res['title_clean'],
                'category_id' => $res['category_id'],
                'subcategory_id' => $res['subcategory_id'],
                'show_id' => $res['show_id'],
                'country_id' => $res['country_id'],
                'confidence' => $res['confidence'],
                'status' => $res['status'],
            ];
            Video::markProcessed($id, $fields);
            $updated++;
        }

        $_SESSION['flash'] = "Backfill completed: {$updated} videos updated.";
        header('Location: ' . self::u('/rules'));
        exit;
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private static function u(string $path, array $query = []): string
    {
        $entry = $_ENV['APP_ENTRYPOINT'] ?? '/app.php';
        if ($path === '' || $path[0] !== '/') {
            $path = '/' . ltrim($path, '/');
        }
        $params = array_merge(['r' => $path], $query);
        return $entry . '?' . http_build_query($params);
    }

    /** @return array<string,mixed> */
    private static function readRuleFromPost(): array
    {
        $name = trim((string)($_POST['name'] ?? ''));
        $matchType = (string)($_POST['match_type'] ?? 'regex');
        if (!in_array($matchType, ['regex', 'contains'], true)) {
            $matchType = 'regex';
        }

        $patternRaw = trim((string)($_POST['pattern'] ?? ''));
        // normalize the pattern so it matches TitleProcessor normalization
        $pattern = self::normalizeText($patternRaw);
        if ($matchType === 'regex') {
            // For regex, don't collapse user intent too much; just strip greek tonos and lowercase.
            // (Title is normalized anyway.)
            $pattern = self::normalizeText($patternRaw);
        }

        $categoryId = $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;
        $subcategoryId = $_POST['subcategory_id'] !== '' ? (int)$_POST['subcategory_id'] : null;

        $confidence = (float)($_POST['confidence'] ?? 0.70);
        if ($confidence < 0.0) $confidence = 0.0;
        if ($confidence > 1.0) $confidence = 1.0;

        $priority = (int)($_POST['priority'] ?? 10);
        $active = isset($_POST['active']) ? 1 : 0;
        $source = (string)($_POST['source'] ?? 'manual');
        if ($source === '') $source = 'manual';

        return [
            'name' => $name,
            'match_type' => $matchType,
            'pattern' => $pattern,
            'category_id' => $categoryId,
            'subcategory_id' => $subcategoryId,
            'confidence' => $confidence,
            'priority' => $priority,
            'active' => $active,
            'source' => $source,
        ];
    }

    private static function normalizeText(string $text): string
    {
        $t = mb_strtolower($text);
        $map = [
            'ά' => 'α', 'έ' => 'ε', 'ή' => 'η', 'ί' => 'ι', 'ό' => 'ο', 'ύ' => 'υ', 'ώ' => 'ω',
            'ϊ' => 'ι', 'ΐ' => 'ι', 'ϋ' => 'υ', 'ΰ' => 'υ',
            'Ά' => 'α', 'Έ' => 'ε', 'Ή' => 'η', 'Ί' => 'ι', 'Ό' => 'ο', 'Ύ' => 'υ', 'Ώ' => 'ω',
        ];
        $t = strtr($t, $map);
        $t = preg_replace('/\s+/u', ' ', $t) ?? $t;
        return trim($t);
    }
}
