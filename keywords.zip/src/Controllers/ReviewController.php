<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Csrf;
use App\Core\DB;
use App\Core\View;
use App\Models\TaxonomyRule;
use App\Models\Video;

/**
 * ReviewController (stable + fast bulk updates + auto-fill category/subcategory on approve)
 *
 * Behavior:
 * - Approve / Approve all / Approve category will TRY to auto-fill category/subcategory for items that are empty
 *   using TaxonomyRule::scoreMatch(title). If no match, it leaves them empty.
 * - Bulk status transitions are done with single SQL UPDATE to reduce SQLite "database is locked".
 * - No dependency on trainer services.
 * - NO-REWRITE friendly redirects.
 */
final class ReviewController
{
    private static function entry(): string
    {
        return (string)($_ENV['APP_ENTRYPOINT'] ?? '/app.php');
    }

    private static function redirect(string $route): void
    {
        $url = self::entry() . '?r=' . $route;
        header('Location: ' . $url, true, 302);
        exit;
    }

    private static function normalizeTitle(string $text): string
    {
        $t = function_exists('mb_strtolower') ? mb_strtolower($text) : strtolower($text);

        $map = [
            'ά' => 'α','έ'=>'ε','ή'=>'η','ί'=>'ι','ό'=>'ο','ύ'=>'υ','ώ'=>'ω',
            'ϊ'=>'ι','ΐ'=>'ι','ϋ'=>'υ','ΰ'=>'υ',
            'Ά'=>'α','Έ'=>'ε','Ή'=>'η','Ί'=>'ι','Ό'=>'ο','Ύ'=>'υ','Ώ'=>'ω',
        ];
        $t = strtr($t, $map);
        $t = preg_replace('/\s+/u', ' ', $t) ?? $t;
        return trim($t);
    }

    /**
     * Auto-fill category/subcategory for the given video IDs (only if empty).
     * Uses rules match; safe: never overwrites existing cat/sub.
     */
    private static function autoFillTaxonomy(array $ids): int
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if (empty($ids)) return 0;

        // cap for safety
        $ids = array_slice($ids, 0, 2000);

        $pdo = DB::pdo();
        $pdo->exec("PRAGMA busy_timeout = 5000");

        // Preload fallback default category "Νέα" (if exists) for news channels
        $defaultNewsCatId = 0;
        try {
            $st = $pdo->prepare("SELECT id FROM taxonomy WHERE type='category' AND name=:n LIMIT 1");
            $st->execute([':n' => 'Νέα']);
            $row = $st->fetch() ?: null;
            if ($row && !empty($row['id'])) $defaultNewsCatId = (int)$row['id'];
        } catch (\Throwable $e) {
            $defaultNewsCatId = 0;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = "SELECT v.id, v.title_raw, v.category_id, v.subcategory_id, v.confidence, v.channel_id,
                       COALESCE(c.news, 0) AS channel_news
                FROM videos v
                LEFT JOIN channels c ON c.id = v.channel_id
                WHERE v.id IN ($placeholders)";
        $st = $pdo->prepare($sql);
        $st->execute($ids);
        $rows = $st->fetchAll() ?: [];

        $updated = 0;

        // prepared update
        $up = $pdo->prepare("
            UPDATE videos
            SET category_id = COALESCE(:category_id, category_id),
                subcategory_id = COALESCE(:subcategory_id, subcategory_id),
                confidence = :confidence
            WHERE id = :id
        ");

        foreach ($rows as $v) {
            $id = (int)($v['id'] ?? 0);
            if ($id <= 0) continue;

            $title = (string)($v['title_raw'] ?? '');
            $hasCat = !empty($v['category_id']) && (int)$v['category_id'] !== 0;
            $hasSub = !empty($v['subcategory_id']) && (int)$v['subcategory_id'] !== 0;

            if ($hasCat && $hasSub) {
                continue; // nothing to fill
            }

            $prevConf = (float)($v['confidence'] ?? 0.0);
            $newCat = null;
            $newSub = null;
            $newConf = $prevConf;

            if ($title !== '') {
                $norm = self::normalizeTitle($title);
                try {
                    $best = TaxonomyRule::scoreMatch($norm);
                } catch (\Throwable $e) {
                    $best = [];
                }

                $bestCat = (int)($best['category_id'] ?? 0);
                $bestSub = (int)($best['subcategory_id'] ?? 0);
                $conf = (float)($best['confidence'] ?? 0.0);

                // Fill what we can, without overwriting
                if (!$hasCat && $bestCat > 0) {
                    $newCat = $bestCat;
                }
                if (!$hasSub && $bestSub > 0) {
                    $newSub = $bestSub;
                }
                $newConf = max($newConf, $conf);
            }

            // Fallback: if still no category, and channel is news, set default category "Νέα"
            if (!$hasCat && ($newCat === null) && (int)($v['channel_news'] ?? 0) === 1 && $defaultNewsCatId > 0) {
                $newCat = $defaultNewsCatId;
                $newConf = max($newConf, 0.40);
            }

            // If we still didn't set anything, skip
            if ($newCat === null && $newSub === null) {
                continue;
            }

            try {
                $up->execute([
                    ':id' => $id,
                    ':category_id' => $newCat,
                    ':subcategory_id' => $newSub,
                    ':confidence' => $newConf,
                ]);
                $updated++;
            } catch (\Throwable $e) {
                // skip
            }
        }

        return $updated;
    }

    public static function index(): void
    {
        AuthService::requireLogin();

        $page = (int)($_GET['page'] ?? 1);
        if ($page < 1) { $page = 1; }

        $videos = Video::search([
            'status' => 'needs_review',
            'sort'   => 'publish_desc',
        ], $page, 200);

        $pdo = DB::pdo();

        $cats = $pdo->query("SELECT id, name FROM taxonomy WHERE type='category' ORDER BY sort, name")->fetchAll() ?: [];
        $subs = $pdo->query("SELECT id, name, parent_id FROM taxonomy WHERE type='subcategory' ORDER BY sort, name")->fetchAll() ?: [];

        $catMap = [];
        foreach ($cats as $c) { $catMap[(int)$c['id']] = (string)$c['name']; }

        $subMap = [];
        foreach ($subs as $s) {
            $subMap[(int)$s['id']] = [
                'name'      => (string)$s['name'],
                'parent_id' => (int)($s['parent_id'] ?? 0),
            ];
        }

        $groups = [];
        foreach ($videos as $v) {
            $catId = isset($v['category_id']) ? (int)$v['category_id'] : 0;
            $subId = isset($v['subcategory_id']) ? (int)$v['subcategory_id'] : 0;

            $catName = ($catId > 0 && isset($catMap[$catId])) ? $catMap[$catId] : 'Uncategorized';
            $subName = '—';
            if ($subId > 0 && isset($subMap[$subId])) {
                $subName = $subMap[$subId]['name'];
            }

            $groups[$catName][$subName][] = $v;
        }

        View::render('review/index', [
            'csrf'   => Csrf::token(),
            'groups' => $groups,
            'page'   => $page,
        ]);
    }

    public static function approve(): void
    {
        AuthService::requireLogin();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Invalid CSRF';
            return;
        }

        try {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) {
                $_SESSION['flash'] = 'Invalid video id.';
                self::redirect('/review');
            }

            // auto-fill before approving (if empty)
            self::autoFillTaxonomy([$id]);

            Video::update($id, ['status' => 'manual']);
            $_SESSION['flash'] = 'Approved.';
            self::redirect('/review');
        } catch (\Throwable $e) {
            $_SESSION['flash'] = 'Approve failed (server error).';
            self::redirect('/review');
        }
    }

    public static function approveBulk(): void
    {
        AuthService::requireLogin();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Invalid CSRF';
            return;
        }

        try {
            $raw = (string)($_POST['ids'] ?? '');
            $ids = array_filter(array_map('intval', preg_split('/[^0-9]+/', $raw)));
            $ids = array_values(array_unique($ids));

            if (empty($ids)) {
                $_SESSION['flash'] = 'No items selected.';
                self::redirect('/review');
            }

            // Auto-fill taxonomy for these ids before we flip status
            $filled = self::autoFillTaxonomy($ids);

            // Cap to avoid overly large IN() clauses
            $ids = array_slice($ids, 0, 2000);

            $pdo = DB::pdo();
            $pdo->exec("PRAGMA busy_timeout = 5000");

            $placeholders = implode(',', array_fill(0, count($ids), '?'));

            $sql = "UPDATE videos SET status='manual' WHERE status='needs_review' AND id IN ($placeholders)";
            $st = $pdo->prepare($sql);
            $st->execute($ids);

            $approved = (int)$st->rowCount();

            $_SESSION['flash'] = "Approved {$approved} items. Auto-filled taxonomy: {$filled}.";
            self::redirect('/review');
        } catch (\Throwable $e) {
            $_SESSION['flash'] = 'Bulk approve failed (server error).';
            self::redirect('/review');
        }
    }

    public static function approveCategory(): void
    {
        AuthService::requireLogin();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Invalid CSRF';
            return;
        }

        try {
            $categoryName = trim((string)($_POST['category'] ?? ''));
            $limit = (int)($_POST['limit'] ?? 2000);
            if ($limit < 1) { $limit = 1; }
            if ($limit > 5000) { $limit = 5000; }

            if ($categoryName === '') {
                $_SESSION['flash'] = 'Missing category.';
                self::redirect('/review');
            }

            $pdo = DB::pdo();
            $pdo->exec("PRAGMA busy_timeout = 5000");

            // Uncategorized
            if ($categoryName === 'Uncategorized') {
                $ids = $pdo->query("SELECT id FROM videos WHERE status='needs_review' AND (category_id IS NULL OR category_id=0) ORDER BY id DESC LIMIT {$limit}")
                           ->fetchAll() ?: [];
                $ids = array_map(fn($r) => (int)($r['id'] ?? 0), $ids);
                $ids = array_values(array_filter($ids));

                if (empty($ids)) {
                    $_SESSION['flash'] = 'Approve category: 0 items.';
                    self::redirect('/review');
                }

                $filled = self::autoFillTaxonomy($ids);

                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $st = $pdo->prepare("UPDATE videos SET status='manual' WHERE status='needs_review' AND id IN ($placeholders)");
                $st->execute($ids);

                $_SESSION['flash'] = "Approve category: " . (int)$st->rowCount() . " items. Auto-filled taxonomy: {$filled}.";
                self::redirect('/review');
            }

            // Resolve category id by name
            $st = $pdo->prepare("SELECT id FROM taxonomy WHERE type='category' AND name=:name LIMIT 1");
            $st->execute([':name' => $categoryName]);
            $row = $st->fetch() ?: null;
            if (!$row || empty($row['id'])) {
                $_SESSION['flash'] = 'Category not found.';
                self::redirect('/review');
            }
            $catId = (int)$row['id'];

            $st = $pdo->prepare("SELECT id FROM videos WHERE status='needs_review' AND category_id=:cat ORDER BY id DESC LIMIT {$limit}");
            $st->execute([':cat' => $catId]);
            $ids = $st->fetchAll() ?: [];
            $ids = array_map(fn($r) => (int)($r['id'] ?? 0), $ids);
            $ids = array_values(array_filter($ids));

            if (empty($ids)) {
                $_SESSION['flash'] = 'Approve category: 0 items.';
                self::redirect('/review');
            }

            $filled = self::autoFillTaxonomy($ids);

            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $st = $pdo->prepare("UPDATE videos SET status='manual' WHERE status='needs_review' AND id IN ($placeholders)");
            $st->execute($ids);

            $_SESSION['flash'] = "Approve category: " . (int)$st->rowCount() . " items. Auto-filled taxonomy: {$filled}.";
            self::redirect('/review');
        } catch (\Throwable $e) {
            $_SESSION['flash'] = 'Approve category failed (server error).';
            self::redirect('/review');
        }
    }
}
