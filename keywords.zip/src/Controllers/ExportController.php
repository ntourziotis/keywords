<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\DB;
use App\Core\Config;
use App\Models\Channel;

final class ExportController
{
    public static function mrss(): void
    {
        // Token-protected (no login needed)
        $token = (string)($_GET['token'] ?? '');
        $expected = Config::get('EXPORT_TOKEN', '');
        if ($expected === '' || !hash_equals($expected, $token)) {
            http_response_code(403);
            echo 'Forbidden';
            return;
        }

        $channelId = (int)($_GET['channel_id'] ?? 0);
        $channel = $channelId ? Channel::find($channelId) : null;
        if (!$channel) {
            http_response_code(404);
            echo 'Channel not found';
            return;
        }

        $limit = (int)($_GET['limit'] ?? 200);
        $limit = max(1, min(1000, $limit));

        $pdo = DB::pdo();

        $sql = "
            SELECT v.id, v.media_id, v.title_raw, v.publish_date,
                   cat.name AS category_name,
                   sub.name AS subcategory_name,
                   sh.name AS show_name,
                   co.name AS country_name
            FROM videos v
            LEFT JOIN taxonomy cat ON cat.id=v.category_id
            LEFT JOIN taxonomy sub ON sub.id=v.subcategory_id
            LEFT JOIN taxonomy sh ON sh.id=v.show_id
            LEFT JOIN taxonomy co ON co.id=v.country_id
            WHERE v.channel_id=:cid
            ORDER BY v.publish_date DESC, v.id DESC
            LIMIT :lim
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':cid', $channelId, \PDO::PARAM_INT);
        $stmt->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        $videos = $stmt->fetchAll();

        header('Content-Type: application/rss+xml; charset=utf-8');

        $baseUrl = Config::get('APP_URL', 'https://keywords.adweb.gr');
        $title = 'Keywords Enriched MRSS - ' . $channel['name'];
        $desc = 'Enriched feed with media:keywords / tags for Connatix / JWP ingest.';

        echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        echo "<rss version=\"2.0\" xmlns:media=\"http://search.yahoo.com/mrss/\">\n";
        echo "  <channel>\n";
        echo "    <title>" . htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</title>\n";
        echo "    <link>" . htmlspecialchars($baseUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</link>\n";
        echo "    <description>" . htmlspecialchars($desc, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</description>\n";

        foreach ($videos as $v) {
            $keywords = self::keywordsForVideo((int)$v['id'], $v);

            echo "    <item>\n";
            echo "      <title>" . htmlspecialchars((string)$v['title_raw'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</title>\n";
            echo "      <guid isPermaLink=\"false\">" . htmlspecialchars((string)$v['media_id'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</guid>\n";

            if (!empty($v['publish_date'])) {
                $ts = strtotime((string)$v['publish_date']);
                if ($ts !== false) {
                    echo "      <pubDate>" . gmdate('D, d M Y H:i:s', $ts) . " GMT</pubDate>\n";
                }
            }

            if (!empty($keywords)) {
                echo "      <media:keywords>" . htmlspecialchars(implode(',', $keywords), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . "</media:keywords>\n";
            }

            echo "    </item>\n";
        }

        echo "  </channel>\n";
        echo "</rss>\n";
    }

    /**
     * @param array<string,mixed> $videoRow
     * @return string[]
     */
    private static function keywordsForVideo(int $videoId, array $videoRow): array
    {
        $pdo = DB::pdo();

        $kw = [];

        foreach (['category_name', 'subcategory_name', 'show_name', 'country_name'] as $k) {
            if (!empty($videoRow[$k])) {
                $kw[] = (string)$videoRow[$k];
            }
        }

        $stmt = $pdo->prepare(
            'SELECT e.name, ve.role FROM video_entities ve JOIN entities e ON e.id=ve.entity_id WHERE ve.video_id=:v AND ve.role IN (\'person\',\'team\',\'trending\') ORDER BY ve.role, e.name'
        );
        $stmt->execute([':v' => $videoId]);
        foreach ($stmt->fetchAll() as $r) {
            $kw[] = (string)$r['name'];
        }

        // unique, keep order
        $seen = [];
        $out = [];
        foreach ($kw as $k) {
            $n = mb_strtolower(trim($k));
            if ($n === '' || isset($seen[$n])) {
                continue;
            }
            $seen[$n] = true;
            $out[] = trim($k);
        }

        return $out;
    }
}
