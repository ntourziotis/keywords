<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Csrf;
use App\Core\View;
use App\Models\Taxonomy;

final class TaxonomyController
{
    /** Build an URL that works both with and without rewrite rules. */
    private static function u(string $path, array $query = []): string
    {
        $entry = $_ENV['APP_ENTRYPOINT'] ?? '/app.php';
        if ($path === '' || $path[0] !== '/') {
            $path = '/' . ltrim($path, '/');
        }
        $params = array_merge(['r' => $path], $query);
        return $entry . '?' . http_build_query($params);
    }

    public static function index(): void
    {
        AuthService::requireLogin();

        $type = (string)($_GET['type'] ?? 'category');
        if (!in_array($type, ['category', 'subcategory', 'show', 'country'], true)) {
            $type = 'category';
        }
        $parentId = isset($_GET['parent_id']) ? (int)($_GET['parent_id']) : null;

        $categories = Taxonomy::categories();
        $rows = Taxonomy::allByType($type);

        View::render('taxonomy/index', [
            'csrf' => Csrf::token(),
            'type' => $type,
            'parent_id' => $parentId,
            'categories' => $categories,
            'rows' => $rows,
        ]);
    }

    public static function create(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $type = trim((string)($_POST['type'] ?? 'category'));
        $name = trim((string)($_POST['name'] ?? ''));
        $sort = (int)($_POST['sort'] ?? 0);
        $active = isset($_POST['active']) ? 1 : 0;
        $parentId = $_POST['parent_id'] !== '' ? (int)$_POST['parent_id'] : null;

        if ($name === '' || !in_array($type, ['category', 'subcategory', 'show', 'country'], true)) {
            $_SESSION['flash'] = 'Invalid taxonomy item.';
            header('Location: ' . self::u('/taxonomy', ['type' => $type]));
            exit;
        }

        Taxonomy::create($type, $parentId, $name, $sort, $active);
        $_SESSION['flash'] = 'Taxonomy item created.';
        header('Location: ' . self::u('/taxonomy', ['type' => $type]));
        exit;
    }

    public static function update(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            http_response_code(400);
            echo 'Bad request';
            exit;
        }

        $data = [
            'name' => trim((string)($_POST['name'] ?? '')),
            'sort' => (int)($_POST['sort'] ?? 0),
            'active' => isset($_POST['active']) ? 1 : 0,
        ];

        Taxonomy::update($id, $data);
        $_SESSION['flash'] = 'Taxonomy item updated.';
        header('Location: ' . self::u('/taxonomy', ['type' => (string)($_POST['type'] ?? 'category')]));
        exit;
    }

    public static function delete(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            Taxonomy::delete($id);
            $_SESSION['flash'] = 'Taxonomy item deleted.';
        }
        header('Location: ' . self::u('/taxonomy', ['type' => (string)($_POST['type'] ?? 'category')]));
        exit;
    }

    public static function dedupe(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $type = (string)($_POST['type'] ?? 'category');
        if (!in_array($type, ['category', 'subcategory', 'show', 'country'], true)) {
            $type = 'category';
        }

        $report = Taxonomy::dedupeRootAndNormalize();
        $merged = (int)($report['merged'] ?? 0);
        $groups = (int)($report['groups'] ?? 0);
        $normalized = (int)($report['normalized'] ?? 0);

        $_SESSION['flash'] = "Fixed duplicates: merged {$merged} rows across {$groups} groups. Normalized {$normalized} roots.";
        header('Location: ' . self::u('/taxonomy', ['type' => $type]));
        exit;
    }
}