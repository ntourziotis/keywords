<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Auth\AuthService;
use App\Core\Csrf;
use App\Core\View;
use App\Models\Channel;
use App\Models\Taxonomy;
use App\Models\Video;
use App\Models\VideoEntity;
use App\Services\RuleTrainer;

final class VideosController
{
    /** Build an URL that works both with and without rewrite rules. */
    private static function u(string $path, array $query = []): string
    {
        $entry = $_ENV['APP_ENTRYPOINT'] ?? '/app.php';
        if ($path === '' || $path[0] !== '/') {
            $path = '/' . ltrim($path, '/');
        }
        $params = array_merge(['r' => $path], $query);
        return $entry . '?' . http_build_query($params);
    }

    private static function nullIfEmpty(mixed $v): ?string
    {
        if ($v === null) {
            return null;
        }
        if (is_string($v)) {
            $v = trim($v);
            if ($v === '') {
                return null;
            }
            $lv = strtolower($v);
            // UI dropdowns often submit "All" for "no filter"
            if ($lv === 'all' || $lv === 'any' || $lv === 'none' || $lv === 'null' || $v === '0') {
                return null;
            }
            return $v;
        }
        if (is_int($v)) {
            return $v === 0 ? null : (string)$v;
        }
        if (is_float($v)) {
            return $v == 0.0 ? null : (string)$v;
        }
        return null;
    }

    public static function index(): void
    {
        AuthService::requireLogin();

        $page = max(1, (int)($_GET['page'] ?? 1));
        $per = (int)($_GET['per'] ?? 25);
        if (!in_array($per, [25, 50, 100], true)) {
            $per = 25;
        }

        $sort = self::nullIfEmpty($_GET['sort'] ?? null) ?? 'publish_desc';
        $allowedSort = ['publish_desc','publish_asc','ingested_desc','ingested_asc','id_desc','id_asc'];
        if (!in_array($sort, $allowedSort, true)) {
            $sort = 'publish_desc';
        }

        $filters = [
            'channel_id' => self::nullIfEmpty($_GET['channel_id'] ?? null),
            'status' => self::nullIfEmpty($_GET['status'] ?? null),
            'category_id' => self::nullIfEmpty($_GET['category_id'] ?? null),
            'q' => self::nullIfEmpty($_GET['q'] ?? null),
            'sort' => $sort,
        ];

        // Cast numeric filters
        foreach (['channel_id', 'category_id'] as $k) {
            if ($filters[$k] !== null && ctype_digit($filters[$k])) {
                $filters[$k] = (string)((int)$filters[$k]);
            } elseif ($filters[$k] !== null) {
                $filters[$k] = null;
            }
        }

        $total = Video::count($filters);
        $pages = (int)ceil(max($total, 1) / $per);
        if ($pages < 1) {
            $pages = 1;
        }
        if ($page > $pages) {
            $page = $pages;
        }

        $rows = Video::search($filters, $page, $per);

        $result = [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'per_page' => $per,
        ];

        $channels = Channel::all();
        $categories = Taxonomy::categories();

        View::render('videos/index', [
            'csrf' => Csrf::token(),
            'channels' => $channels,
            'categories' => $categories,
            'filters' => $filters,
            'result' => $result,
            'per' => $per,
            'page' => $page,
        ]);
    }

    public static function editForm(): void
    {
        AuthService::requireLogin();

        $id = (int)($_GET['id'] ?? 0);
        $video = $id ? Video::find($id) : null;
        if (!$video) {
            http_response_code(404);
            echo 'Not found';
            return;
        }

        $categories = Taxonomy::categories();
        $shows = Taxonomy::shows();
        $countries = Taxonomy::countries();
        $subcategories = [];
        if (!empty($video['category_id'])) {
            $subcategories = Taxonomy::subcategoriesByParent((int)$video['category_id']);
        }

        $persons = VideoEntity::listTermsForVideo($id, 'person');
        $teams = VideoEntity::listTermsForVideo($id, 'team');
        $trendings = VideoEntity::listTermsForVideo($id, 'trending');

        View::render('videos/edit', [
            'csrf' => Csrf::token(),
            'video' => $video,
            'categories' => $categories,
            'subcategories' => $subcategories,
            'shows' => $shows,
            'countries' => $countries,
            'persons' => $persons,
            'teams' => $teams,
            'trendings' => $trendings,
        ]);
    }

    public static function update(): void
    {
        AuthService::requireLogin();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $id = (int)($_GET['id'] ?? 0);
        $video = $id ? Video::find($id) : null;
        if (!$video) {
            http_response_code(404);
            echo 'Not found';
            exit;
        }

        $fields = [
            'category_id' => $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null,
            'subcategory_id' => $_POST['subcategory_id'] !== '' ? (int)$_POST['subcategory_id'] : null,
            'show_id' => $_POST['show_id'] !== '' ? (int)$_POST['show_id'] : null,
            'country_id' => $_POST['country_id'] !== '' ? (int)$_POST['country_id'] : null,
            'status' => 'manual',
            'confidence' => 1.0,
        ];
        Video::updateManual($id, $fields);

        // Auto-train: generate a couple of lightweight rules from this manual edit
        // so future similar titles get filled automatically.
        $autoTrain = getenv('AUTO_TRAIN_ON_MANUAL_EDIT');
        if ($autoTrain === false || $autoTrain === '' || $autoTrain === '1' || $autoTrain === 'true') {
            try {
                RuleTrainer::trainFromManual((string)($video['title_raw'] ?? ''), (int)($fields['category_id'] ?? 0), $fields['subcategory_id'] !== null ? (int)$fields['subcategory_id'] : null);
            } catch (\Throwable $e) {
                // don't block the UI if training fails
            }
        }

        $_SESSION['flash'] = 'Video updated (manual).';
        header('Location: ' . self::u('/videos/edit', ['id' => $id]));
        exit;
    }

    public static function delete(): void
    {
        AuthService::requireRole('admin');
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            Video::delete($id);
            $_SESSION['flash'] = 'Video deleted.';
        }
        header('Location: ' . self::u('/videos'));
        exit;
    }

    public static function bulk(): void
    {
        AuthService::requireLogin();
        if (!Csrf::validate($_POST['csrf'] ?? null)) {
            http_response_code(400);
            echo 'Bad CSRF';
            exit;
        }

        $ids = array_map('intval', $_POST['ids'] ?? []);
        $ids = array_values(array_filter($ids, fn($v) => $v > 0));

        $fields = [
            'category_id' => $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null,
            'subcategory_id' => $_POST['subcategory_id'] !== '' ? (int)$_POST['subcategory_id'] : null,
            'show_id' => $_POST['show_id'] !== '' ? (int)$_POST['show_id'] : null,
            'country_id' => $_POST['country_id'] !== '' ? (int)$_POST['country_id'] : null,
            'confidence' => 1.0,
        ];

        $n = Video::bulkSet($ids, $fields);
        $_SESSION['flash'] = "Bulk update applied to {$n} videos.";
        header('Location: ' . self::u('/videos'));
        exit;
    }
}
