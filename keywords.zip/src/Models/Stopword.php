<?php

declare(strict_types=1);

namespace App\Models;

final class Stopword extends BaseModel
{
    public static function all(): array
    {
        $stmt = self::pdo()->query('SELECT word FROM stopwords ORDER BY word ASC');
        return $stmt->fetchAll();
    }

    public static function add(string $word): void
    {
        $word = trim($word);
        // Some hosting setups have mbstring enabled for CLI but not for web.
        // Stopwords entry should never hard-fail because of mbstring.
        if (function_exists('mb_strtolower')) {
            $word = mb_strtolower($word, 'UTF-8');
        } else {
            $word = strtolower($word);
        }
        if ($word === '') {
            return;
        }
        $stmt = self::pdo()->prepare('INSERT OR IGNORE INTO stopwords (word) VALUES (:w)');
        $stmt->execute([':w' => $word]);
    }

    public static function delete(string $word): void
    {
        $stmt = self::pdo()->prepare('DELETE FROM stopwords WHERE word=:w');
        $stmt->execute([':w' => $word]);
    }

    public static function listAsSet(): array
    {
        $rows = self::all();
        $set = [];
        foreach ($rows as $r) {
            $set[(string)$r['word']] = true;
        }
        return $set;
    }
}
