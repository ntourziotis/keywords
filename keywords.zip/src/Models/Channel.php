<?php

declare(strict_types=1);

namespace App\Models;

final class Channel extends BaseModel
{
    public static function all(): array
    {
        $stmt = self::pdo()->query('SELECT * FROM channels ORDER BY name ASC');
        return $stmt->fetchAll();
    }

    public static function allActive(): array
    {
        $stmt = self::pdo()->query('SELECT * FROM channels WHERE active = 1 ORDER BY name ASC');
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $stmt = self::pdo()->prepare('SELECT * FROM channels WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int
    {
        $stmt = self::pdo()->prepare(
            'INSERT INTO channels (name, source_type, source_url, is_news, poll_every_seconds, active, created_at) VALUES (:n, :t, :u, :news, :poll, :a, :c)'
        );
        $stmt->execute([
            ':n' => $data['name'],
            ':t' => $data['source_type'] ?? 'mrss',
            ':u' => $data['source_url'],
            ':news' => (int)($data['is_news'] ?? 1),
            ':poll' => (int)($data['poll_every_seconds'] ?? 60),
            ':a' => (int)($data['active'] ?? 1),
            ':c' => date('Y-m-d H:i:s'),
        ]);
        return (int) self::pdo()->lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $stmt = self::pdo()->prepare(
            'UPDATE channels SET name=:n, source_type=:t, source_url=:u, is_news=:news, poll_every_seconds=:poll, active=:a WHERE id=:id'
        );
        $stmt->execute([
            ':n' => $data['name'],
            ':t' => $data['source_type'] ?? 'mrss',
            ':u' => $data['source_url'],
            ':news' => (int)($data['is_news'] ?? 1),
            ':poll' => (int)($data['poll_every_seconds'] ?? 60),
            ':a' => (int)($data['active'] ?? 1),
            ':id' => $id,
        ]);
    }

    public static function delete(int $id): void
    {
        $stmt = self::pdo()->prepare('DELETE FROM channels WHERE id = :id');
        $stmt->execute([':id' => $id]);
    }

    public static function touchPollStatus(int $id, string $status, ?string $message = null): void
    {
        $stmt = self::pdo()->prepare('UPDATE channels SET last_poll_at=:t, last_poll_status=:s, last_poll_message=:m WHERE id=:id');
        $stmt->execute([
            ':t' => date('Y-m-d H:i:s'),
            ':s' => $status,
            ':m' => $message,
            ':id' => $id,
        ]);
    }
}
