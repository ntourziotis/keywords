<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\DB;
use PDO;

final class MlPrediction
{
    private static function pdo(): PDO
    {
        return DB::pdo();
    }

    /**
     * @param array<string,mixed> $payload
     */
    public static function upsertLatest(int $videoId, array $payload): void
    {
        $pdo = self::pdo();
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            $json = '{}';
        }

        $version = null;
        if (isset($payload['model_version']) && is_string($payload['model_version'])) {
            $version = $payload['model_version'];
        }

        $now = date('Y-m-d H:i:s');
        $sql = 'INSERT INTO ml_predictions (video_id, model_version, predictions_json, created_at, updated_at)
                VALUES (:v, :mv, :j, :c, :u)
                ON CONFLICT(video_id) DO UPDATE SET
                  model_version=excluded.model_version,
                  predictions_json=excluded.predictions_json,
                  updated_at=excluded.updated_at';

        $st = $pdo->prepare($sql);
        $st->execute([
            ':v' => $videoId,
            ':mv' => $version,
            ':j' => $json,
            ':c' => $now,
            ':u' => $now,
        ]);
    }

    /** @return array<string,mixed>|null */
    public static function latestForVideo(int $videoId): ?array
    {
        $st = self::pdo()->prepare('SELECT * FROM ml_predictions WHERE video_id = :v LIMIT 1');
        $st->execute([':v' => $videoId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) return null;

        $payload = json_decode((string)($row['predictions_json'] ?? ''), true);
        if (!is_array($payload)) $payload = [];

        return [
            'video_id' => (int)($row['video_id'] ?? 0),
            'model_version' => (string)($row['model_version'] ?? ''),
            'payload' => $payload,
            'created_at' => (string)($row['created_at'] ?? ''),
            'updated_at' => (string)($row['updated_at'] ?? ''),
        ];
    }
}
