<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

// Guard against accidental double-includes
if (!class_exists(__NAMESPACE__ . '\\Taxonomy', false)) {

final class Taxonomy extends BaseModel
{
    public static function create(string $type, ?int $parentId, string $name, int $sort = 0, int $active = 1): int
    {
        return Entity::upsert($type, $name, $parentId, $sort, $active);
    }

    public static function upsert(string $type, $name, ?int $parentId = null, int $sort = 0, int $active = 1): int
    {
        return Entity::upsert($type, $name, $parentId, $sort, $active);
    }

    public static function findId(string $type, $name, ?int $parentId = null): ?int
    {
        return Entity::findId($type, $name, $parentId);
    }

    /** Used by TitleProcessor & controllers */
    public static function findByTypeAndName(string $type, $name, ?int $parentId = null): ?array
    {
        $pdo = self::pdo();

        $type = trim($type);
        $name = trim((string)$name);
        if ($type === '' || $name === '') return null;

        $sql = "SELECT * FROM taxonomy WHERE type = :t AND name = :n";
        $bind = [':t' => $type, ':n' => $name];

        if ($parentId === null) {
            $sql .= " AND (parent_id IS NULL OR parent_id = 0)";
        } else {
            $sql .= " AND parent_id = :p";
            $bind[':p'] = $parentId;
        }

        $sql .= " LIMIT 1";
        $st = $pdo->prepare($sql);
        $st->execute($bind);
        $row = $st->fetch(PDO::FETCH_ASSOC);

        return $row ?: null;
    }

    public static function findByTypeAndTitle(string $type, $title, ?int $parentId = null): ?array
    {
        return self::findByTypeAndName($type, $title, $parentId);
    }

    /** Generic list by type + optional parent */
    public static function listByType(string $type, ?int $parentId = null): array
    {
        $pdo = self::pdo();

        $sql = "SELECT * FROM taxonomy WHERE type = :t";
        $bind = [':t' => $type];

        if ($parentId === null) {
            $sql .= " AND (parent_id IS NULL OR parent_id = 0)";
        } else {
            $sql .= " AND parent_id = :p";
            $bind[':p'] = $parentId;
        }

        $sql .= " ORDER BY sort ASC, name ASC";
        $st = $pdo->prepare($sql);
        $st->execute($bind);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Controller compatibility (TaxonomyController) */
    public static function allByType(string $type, ?int $parentId = null): array
    {
        if ($type === 'subcategory') {
            // when no parent is provided, return all subcategories
            if ($parentId === null) {
                $st = self::pdo()->prepare("SELECT * FROM taxonomy WHERE type='subcategory' ORDER BY parent_id ASC, sort ASC, name ASC");
                $st->execute();
                return $st->fetchAll(PDO::FETCH_ASSOC);
            }
            return self::listByType('subcategory', $parentId);
        }

        return self::listByType($type, $parentId);
    }

    /** Update taxonomy item fields. @param array<string,mixed> $data */
    public static function update(int $id, array $data): void
    {
        $allowed = ['name', 'sort', 'active', 'parent_id', 'type'];
        $set = [];
        $bind = [':id' => $id];
        foreach ($allowed as $k) {
            if (!array_key_exists($k, $data)) continue;
            $set[] = "$k=:$k";
            $bind[":$k"] = $data[$k];
        }
        if (!$set) return;
        $sql = 'UPDATE taxonomy SET ' . implode(', ', $set) . ' WHERE id=:id';
        self::pdo()->prepare($sql)->execute($bind);
    }

    public static function delete(int $id): void
    {
        self::pdo()->prepare('DELETE FROM taxonomy WHERE id=:id')->execute([':id' => $id]);
    }

    /** Return parent_id for taxonomy item (or null if not found). */
    public static function parentIdOf(int $id): ?int
    {
        $st = self::pdo()->prepare('SELECT parent_id FROM taxonomy WHERE id=:id LIMIT 1');
        $st->execute([':id' => $id]);
        $v = $st->fetchColumn();
        if ($v === false || $v === null || $v === '') return null;
        return (int)$v;
    }

    /** Compatibility: VideosController expects Taxonomy::categories() */
    public static function categories(): array
    {
        return self::listByType('category', null);
    }

    /** Common helpers */
    public static function shows(): array
    {
        return self::listByType('show', null);
    }

    public static function countries(): array
    {
        return self::listByType('country', null);
    }

    /** Subcategories for a category id */
    public static function subcategories(?int $categoryId = null): array
    {
        if ($categoryId === null) {
            $st = self::pdo()->prepare("SELECT * FROM taxonomy WHERE type='subcategory' ORDER BY parent_id ASC, sort ASC, name ASC");
            $st->execute();
            return $st->fetchAll(PDO::FETCH_ASSOC);
        }
        return self::listByType('subcategory', $categoryId);
    }

    /** Backward-compatible alias used by older controllers (parent is category id). */
    public static function subcategoriesByParent(int $parentId): array
    {
        return self::listByType('subcategory', $parentId);
    }

    public static function children(int $parentId): array
    {
        $pdo = self::pdo();
        $st = $pdo->prepare("SELECT * FROM taxonomy WHERE parent_id = :p ORDER BY sort ASC, name ASC");
        $st->execute([':p' => $parentId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Fix duplicates ONLY at ROOT level (parent_id NULL/0), merge safely, then normalize root parent_id to 0.
     * This permanently prevents duplicates with the existing UNIQUE(type,parent_id,name) constraint.
     *
     * @return array{groups:int,merged:int,normalized:int}
     */
    public static function dedupeRootAndNormalize(): array
    {
        $pdo = self::pdo();

        // Reduce "database is locked" issues.
        try { $pdo->exec('PRAGMA busy_timeout=5000'); } catch (\Throwable $e) {}
        try { $pdo->exec('PRAGMA journal_mode=WAL'); } catch (\Throwable $e) {}

        // Detect optional columns to avoid crashes.
        $hasRules = true;
        try { $pdo->query("SELECT 1 FROM taxonomy_rules LIMIT 1"); } catch (\Throwable $e) { $hasRules = false; }

        // video cols exist in our schema, but be defensive
        $videoCols = [];
        try {
            $st = $pdo->query("PRAGMA table_info('videos')");
            foreach (($st ? $st->fetchAll(PDO::FETCH_ASSOC) : []) as $r) {
                $videoCols[(string)($r['name'] ?? '')] = true;
            }
        } catch (\Throwable $e) {}

        $typeToVideoCol = [
            'category' => 'category_id',
            'subcategory' => 'subcategory_id',
            'show' => 'show_id',
            'country' => 'country_id',
        ];

        $groups = 0;
        $merged = 0;

        try {
            $pdo->beginTransaction();

            // recursive merge node
            $mergeNode = function (int $dupId, int $keepId, string $type) use ($pdo, &$mergeNode, $hasRules, $videoCols, $typeToVideoCol, &$merged): void {
                if ($dupId === $keepId) return;

                // Merge meta (keep best active and lowest sort)
                $st = $pdo->prepare('SELECT MAX(active) AS max_active, MIN(sort) AS min_sort FROM taxonomy WHERE id IN (?, ?)');
                $st->execute([$keepId, $dupId]);
                $agg = $st->fetch(PDO::FETCH_ASSOC) ?: [];
                $pdo->prepare('UPDATE taxonomy SET active=:a, sort=:s WHERE id=:id')
                    ->execute([
                        ':a' => isset($agg['max_active']) ? (int)$agg['max_active'] : 1,
                        ':s' => isset($agg['min_sort']) ? (int)$agg['min_sort'] : 0,
                        ':id' => $keepId,
                    ]);

                // Merge children safely
                $stCh = $pdo->prepare('SELECT id,type,name FROM taxonomy WHERE parent_id = :p ORDER BY id ASC');
                $stCh->execute([':p' => $dupId]);
                $children = $stCh->fetchAll(PDO::FETCH_ASSOC) ?: [];

                foreach ($children as $ch) {
                    $childId = (int)($ch['id'] ?? 0);
                    $childType = (string)($ch['type'] ?? '');
                    $childName = (string)($ch['name'] ?? '');
                    if ($childId <= 0 || $childType === '' || $childName === '') continue;

                    $stEq = $pdo->prepare('SELECT id FROM taxonomy WHERE parent_id=:p AND type=:t AND name=:n LIMIT 1');
                    $stEq->execute([':p' => $keepId, ':t' => $childType, ':n' => $childName]);
                    $eqId = (int)($stEq->fetchColumn() ?: 0);

                    if ($eqId > 0) {
                        $mergeNode($childId, $eqId, $childType);
                    } else {
                        $pdo->prepare('UPDATE taxonomy SET parent_id=:keep WHERE id=:id')
                            ->execute([':keep' => $keepId, ':id' => $childId]);
                    }
                }

                // Update external references (videos)
                $vcol = $typeToVideoCol[$type] ?? null;
                if ($vcol && isset($videoCols[$vcol])) {
                    $pdo->prepare("UPDATE videos SET {$vcol}=:keep WHERE {$vcol}=:dup")
                        ->execute([':keep' => $keepId, ':dup' => $dupId]);
                }

                // Update rules references
                if ($hasRules) {
                    if ($type === 'category') {
                        $pdo->prepare('UPDATE taxonomy_rules SET category_id=:keep WHERE category_id=:dup')
                            ->execute([':keep' => $keepId, ':dup' => $dupId]);
                    }
                    if ($type === 'subcategory') {
                        $pdo->prepare('UPDATE taxonomy_rules SET subcategory_id=:keep WHERE subcategory_id=:dup')
                            ->execute([':keep' => $keepId, ':dup' => $dupId]);
                    }
                }

                // Delete duplicate
                $pdo->prepare('DELETE FROM taxonomy WHERE id=:dup')->execute([':dup' => $dupId]);
                $merged++;
            };

            // Find duplicates at root for each type
            $stGroups = $pdo->query("SELECT type, name, GROUP_CONCAT(id) AS ids, COUNT(*) AS cnt
                                    FROM taxonomy
                                    WHERE COALESCE(parent_id,0)=0
                                    GROUP BY type, name
                                    HAVING COUNT(*) > 1");
            $dupGroups = $stGroups ? $stGroups->fetchAll(PDO::FETCH_ASSOC) : [];

            foreach ($dupGroups as $g) {
                $ids = array_filter(array_map('intval', explode(',', (string)($g['ids'] ?? ''))));
                $ids = array_values(array_unique($ids));
                sort($ids);
                if (count($ids) < 2) continue;

                $groups++;
                $keep = $ids[0];
                $type = (string)($g['type'] ?? '');
                if ($type === '') continue;

                foreach (array_slice($ids, 1) as $dupId) {
                    $mergeNode($dupId, $keep, $type);
                }
            }

            // Normalize NULL roots to 0 (after merge)
            $stNorm = $pdo->prepare('UPDATE taxonomy SET parent_id = 0 WHERE parent_id IS NULL');
            $stNorm->execute();
            $normalized = $stNorm->rowCount();

            $pdo->commit();

            return ['groups' => $groups, 'merged' => $merged, 'normalized' => $normalized];
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                try { $pdo->rollBack(); } catch (\Throwable $e2) {}
            }
            // Bubble up as runtime exception so controller can show it via flash
            throw new \RuntimeException($e->getMessage(), 0, $e);
        }
    }
}

} // guard
