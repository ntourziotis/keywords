<?php

declare(strict_types=1);

namespace App\Models;

final class ErrorLog extends BaseModel
{
    public static function create(string $context, ?string $refId, string $message, ?string $trace = null): void
    {
        $stmt = self::pdo()->prepare('INSERT INTO error_logs (context, ref_id, message, trace, created_at) VALUES (:c, :r, :m, :t, :a)');
        $stmt->execute([
            ':c' => $context,
            ':r' => $refId,
            ':m' => $message,
            ':t' => $trace,
            ':a' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * @return array<int, array<string,mixed>>
     */
    public static function recent(int $limit = 200, bool $includeResolved = true): array
    {
        $sql = 'SELECT * FROM error_logs ';
        if (!$includeResolved) {
            $sql .= 'WHERE resolved=0 ';
        }
        $sql .= 'ORDER BY id DESC LIMIT :l';

        $stmt = self::pdo()->prepare($sql);
        $stmt->bindValue(':l', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function resolve(int $id): void
    {
        $stmt = self::pdo()->prepare('UPDATE error_logs SET resolved=1 WHERE id=:id');
        $stmt->execute([':id' => $id]);
    }
}
