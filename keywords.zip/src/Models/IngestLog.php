<?php

declare(strict_types=1);

namespace App\Models;

final class IngestLog extends BaseModel
{
    public static function start(int $channelId): int
    {
        $stmt = self::pdo()->prepare('INSERT INTO ingest_logs (channel_id, started_at, status) VALUES (:c, :s, :st)');
        $stmt->execute([
            ':c' => $channelId,
            ':s' => date('Y-m-d H:i:s'),
            ':st' => 'running',
        ]);
        return (int) self::pdo()->lastInsertId();
    }

    public static function finish(int $logId, array $fields): void
    {
        $stmt = self::pdo()->prepare('UPDATE ingest_logs SET finished_at=:f, items_seen=:seen, items_new=:new, items_updated=:upd, status=:st, message=:m WHERE id=:id');
        $stmt->execute([
            ':f' => date('Y-m-d H:i:s'),
            ':seen' => (int)($fields['items_seen'] ?? 0),
            ':new' => (int)($fields['items_new'] ?? 0),
            ':upd' => (int)($fields['items_updated'] ?? 0),
            ':st' => $fields['status'] ?? 'ok',
            ':m' => $fields['message'] ?? null,
            ':id' => $logId,
        ]);
    }

    public static function recent(int $limit = 20): array
    {
        $stmt = self::pdo()->prepare('SELECT l.*, c.name AS channel_name FROM ingest_logs l JOIN channels c ON c.id=l.channel_id ORDER BY l.id DESC LIMIT :lim');
        $stmt->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
