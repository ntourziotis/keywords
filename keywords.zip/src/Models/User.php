<?php

declare(strict_types=1);

namespace App\Models;

final class User extends BaseModel
{
    public static function findByEmail(string $email): ?array
    {
        $stmt = self::pdo()->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findById(int $id): ?array
    {
        $stmt = self::pdo()->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(string $email, string $password, string $role = 'admin'): int
    {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = self::pdo()->prepare('INSERT INTO users (email, password_hash, role, created_at) VALUES (:e, :h, :r, :c)');
        $stmt->execute([
            ':e' => $email,
            ':h' => $hash,
            ':r' => $role,
            ':c' => date('Y-m-d H:i:s'),
        ]);
        return (int) self::pdo()->lastInsertId();
    }
}
