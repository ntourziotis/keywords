<?php
declare(strict_types=1);

namespace App\Models;

use PDO;
use PDOException;

if (!class_exists(__NAMESPACE__ . '\\Entity', false)) {

final class Entity extends BaseModel
{
    /** @var array<string,bool> */
    private static array $colCache = [];

    private static function hasColumn(string $table, string $col): bool
    {
        $key = $table . '.' . $col;
        if (array_key_exists($key, self::$colCache)) {
            return self::$colCache[$key];
        }

        $pdo = self::pdo();
        $st = $pdo->query("PRAGMA table_info(" . $table . ")");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            if (($row['name'] ?? null) === $col) {
                return self::$colCache[$key] = true;
            }
        }
        return self::$colCache[$key] = false;
    }

    public static function upsert(string $type, $name, ?int $parentId = null, int $sort = 0, int $active = 1): int
    {
        $pdo = self::pdo();

        $type = trim($type);
        $name = trim((string)$name);

        
        $pidForInsert = $parentId ?? 0;
if ($type === '' || $name === '') return 0;

        $hasActive = self::hasColumn('taxonomy', 'active');
        $hasSort   = self::hasColumn('taxonomy', 'sort');

        $sql = "SELECT id FROM taxonomy WHERE type = :type AND name = :name";
        $bind = [':type' => $type, ':name' => $name];

        if ($parentId === null) {
            // Treat NULL and 0 as "root". (SQLite UNIQUE doesn't consider NULL equal to NULL.)
            $sql .= " AND (parent_id IS NULL OR parent_id = 0)";
        } else {
            $sql .= " AND parent_id = :pid";
            $bind[':pid'] = $parentId;
        }
        $sql .= " LIMIT 1";

        $st = $pdo->prepare($sql);
        $st->execute($bind);
        $id = $st->fetchColumn();
        if ($id !== false && $id !== null) return (int)$id;

        $cols = ['type', 'parent_id', 'name'];
        $vals = [':type', ':pid', ':name'];
        $insBind = [':type' => $type, ':pid' => $pidForInsert, ':name' => $name];

        if ($hasSort)   { $cols[] = 'sort';   $vals[] = ':sort';   $insBind[':sort'] = $sort; }
        if ($hasActive) { $cols[] = 'active'; $vals[] = ':active'; $insBind[':active'] = $active; }

        $insSql = "INSERT INTO taxonomy (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ")";

        try {
            $pdo->prepare($insSql)->execute($insBind);
            return (int)$pdo->lastInsertId();
        } catch (PDOException $e) {
            $st = $pdo->prepare($sql);
            $st->execute($bind);
            $id = $st->fetchColumn();
            return ($id !== false && $id !== null) ? (int)$id : 0;
        }
    }

    public static function findId(string $type, $name, ?int $parentId = null): ?int
    {
        $pdo = self::pdo();

        $type = trim($type);
        $name = trim((string)$name);
        if ($type === '' || $name === '') return null;

        $sql = "SELECT id FROM taxonomy WHERE type = :type AND name = :name";
        $bind = [':type' => $type, ':name' => $name];

        if ($parentId === null) {
            $sql .= " AND (parent_id IS NULL OR parent_id = 0)";
        } else {
            $sql .= " AND parent_id = :pid";
            $bind[':pid'] = $parentId;
        }
        $sql .= " LIMIT 1";

        $st = $pdo->prepare($sql);
        $st->execute($bind);
        $id = $st->fetchColumn();

        return ($id !== false && $id !== null) ? (int)$id : null;
    }
}

} // guard
