<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\DB;
use PDO;

final class Video
{
    /** @var array<string, bool> */
    private static array $colsCache = [];

    private static function pdo(): PDO
    {
        return DB::pdo();
    }

    /** @return array<string, bool> */
    private static function cols(): array
    {
        if (self::$colsCache) {
            return self::$colsCache;
        }
        $pdo = self::pdo();
        $st = $pdo->query("PRAGMA table_info(videos)");
        $cols = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $name = (string)($row['name'] ?? '');
            if ($name !== '') {
                $cols[$name] = true;
            }
        }
        self::$colsCache = $cols;
        return $cols;
    }

    private static function has(string $col): bool
    {
        $c = self::cols();
        return isset($c[$col]);
    }

    public static function findById(int $id): ?array
    {
        $st = self::pdo()->prepare("SELECT * FROM videos WHERE id=:id LIMIT 1");
        $st->execute([':id' => $id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }


    /** Backward-compatible alias used by controllers. */
    public static function find(int $id): ?array
    {
        return self::findById($id);
    }

    /** Delete a single video by id. */
    public static function delete(int $id): void
    {
        $st = self::pdo()->prepare('DELETE FROM videos WHERE id = :id');
        $st->execute([':id' => $id]);
    }

    /**
     * Manual update from the UI.
     * Sets status=manual and confidence=1.0 unless explicitly provided.
     *
     * @param array<string,mixed> $fields
     */
    public static function updateManual(int $id, array $fields): void
    {
        $cols = self::cols();

        if (!array_key_exists('status', $fields)) {
            $fields['status'] = 'manual';
        }
        if (!array_key_exists('confidence', $fields)) {
            $fields['confidence'] = 1.0;
        }

        $allowed = ['category_id','subcategory_id','show_id','country_id','status','confidence'];
        $set = [];
        $bind = [':id' => $id];

        foreach ($allowed as $k) {
            if (!array_key_exists($k, $fields)) {
                continue;
            }
            if (!isset($cols[$k])) {
                continue;
            }
            $ph = ':' . $k;
            $set[] = "$k = $ph";
            $bind[$ph] = $fields[$k];
        }

        if (isset($cols['updated_at'])) {
            $set[] = 'updated_at = :updated_at';
            $bind[':updated_at'] = date('Y-m-d H:i:s');
        }

        if (!$set) {
            return;
        }

        $sql = 'UPDATE videos SET ' . implode(', ', $set) . ' WHERE id = :id';
        self::pdo()->prepare($sql)->execute($bind);
    }

    /**
     * Bulk update selected videos.
     * Null values mean "no change".
     *
     * @param array<int,int> $ids
     * @param array<string,mixed> $fields
     */
    public static function bulkSet(array $ids, array $fields): int
    {
        $ids = array_values(array_filter(array_map('intval', $ids), static fn($v) => $v > 0));
        if (!$ids) {
            return 0;
        }

        $cols = self::cols();
        $allowed = ['category_id','subcategory_id','show_id','country_id','status','confidence'];

        $set = [];
        $bind = [];

        foreach ($allowed as $k) {
            if (!array_key_exists($k, $fields)) {
                continue;
            }
            if ($fields[$k] === null) {
                continue; // no change
            }
            if (!isset($cols[$k])) {
                continue;
            }
            $ph = ':' . $k;
            $set[] = "$k = $ph";
            $bind[$ph] = $fields[$k];
        }

        if (isset($cols['updated_at'])) {
            $set[] = 'updated_at = :updated_at';
            $bind[':updated_at'] = date('Y-m-d H:i:s');
        }

        if (!$set) {
            return 0;
        }

        $idPlaceholders = [];
        foreach ($ids as $i => $id) {
            $ph = ':vid' . $i;
            $idPlaceholders[] = $ph;
            $bind[$ph] = $id;
        }

        $sql = 'UPDATE videos SET ' . implode(', ', $set) . ' WHERE id IN (' . implode(',', $idPlaceholders) . ')';
        $st = self::pdo()->prepare($sql);
        $st->execute($bind);
        return (int)$st->rowCount();
    }

    public static function findByChannelAndMedia(int $channelId, string $mediaId): ?array
    {
        $st = self::pdo()->prepare("SELECT * FROM videos WHERE channel_id=:c AND media_id=:m LIMIT 1");
        $st->execute([':c' => $channelId, ':m' => $mediaId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Upsert a video record and return the stored row.
     *
     * @param array<string,mixed> $extra Optional fields: video_url/url, page_url, thumbnail, duration, description_raw/description
     * @return array<string,mixed>
     */
    public static function upsert(int $channelId, string $mediaId, ?string $publishDate, string $titleRaw, array $extra = []): array
    {
        $pdo = self::pdo();

        // Normalize extra fields (url -> video_url when applicable)
        $extra = self::normalizeExtra($extra);

        $existing = self::findByChannelAndMedia($channelId, $mediaId);
        $now = date('Y-m-d H:i:s');

        if (!$existing) {
            $fields = [
                'channel_id' => $channelId,
                'media_id' => $mediaId,
                'title_raw' => $titleRaw,
                'publish_date' => $publishDate,
                'status' => $extra['status'] ?? 'new',
            ];

            if (self::has('last_ingested_at')) {
                $fields['last_ingested_at'] = $now;
            }

            // apply optional fields if columns exist
            foreach (['video_url','page_url','thumbnail','duration','description_raw'] as $k) {
                if (isset($extra[$k]) && $extra[$k] !== '' && self::has($k)) {
                    $fields[$k] = $extra[$k];
                }
            }

            $cols = array_keys($fields);
            $ph = array_map(fn($c) => ':' . $c, $cols);

            $sql = "INSERT INTO videos (" . implode(',', $cols) . ") VALUES (" . implode(',', $ph) . ")";
            $st = $pdo->prepare($sql);
            foreach ($fields as $k => $v) {
                $st->bindValue(':' . $k, $v);
            }
            $st->execute();

            $id = (int)$pdo->lastInsertId();
            return self::findById($id) ?? $fields;
        }

        // Update ingest basics + fill missing optional fields
        $updates = [];
        $bind = [':id' => (int)$existing['id']];

        if (self::has('title_raw') && $titleRaw !== '' && (string)($existing['title_raw'] ?? '') !== $titleRaw) {
            $updates[] = "title_raw=:t";
            $bind[':t'] = $titleRaw;
        }
        if (self::has('publish_date') && $publishDate && (string)($existing['publish_date'] ?? '') === '') {
            $updates[] = "publish_date=:p";
            $bind[':p'] = $publishDate;
        }
        if (self::has('last_ingested_at')) {
            $updates[] = "last_ingested_at=:i";
            $bind[':i'] = $now;
        }

        foreach (['video_url','page_url','thumbnail','duration','description_raw'] as $k) {
            if (!self::has($k)) {
                continue;
            }
            if (!isset($extra[$k])) {
                continue;
            }
            $val = $extra[$k];
            if ($val === null || $val === '' || (is_int($val) && $val <= 0)) {
                continue;
            }
            $cur = $existing[$k] ?? null;
            $isEmpty = ($cur === null || (is_string($cur) && trim($cur) === '') || (is_int($cur) && (int)$cur === 0));
            if ($isEmpty) {
                $ph = ':x_' . $k;
                $updates[] = "{$k}={$ph}";
                $bind[$ph] = $val;
            }
        }

        if ($updates) {
            $sql = "UPDATE videos SET " . implode(', ', $updates) . " WHERE id=:id";
            $pdo->prepare($sql)->execute($bind);
        }

        return self::findById((int)$existing['id']) ?? $existing;
    }

    /** @param array<string,mixed> $data */
    private static function normalizeExtra(array $data): array
    {
        // accept description as description_raw
        if (!isset($data['description_raw']) && isset($data['description']) && is_string($data['description'])) {
            $data['description_raw'] = $data['description'];
        }

        // Normalize URL fields
        $url = '';
        foreach (['video_url','url','enclosure_url','content_url','media_url','file_url'] as $k) {
            if (isset($data[$k]) && is_string($data[$k]) && trim($data[$k]) !== '') {
                $url = trim($data[$k]);
                break;
            }
        }
        if ($url !== '') {
            // if table has video_url, prefer that
            if (self::has('video_url') && (!isset($data['video_url']) || trim((string)$data['video_url']) === '')) {
                $data['video_url'] = $url;
            }
            // keep backward-compatible key as well
            if (!isset($data['url']) || trim((string)$data['url']) === '') {
                $data['url'] = $url;
            }
        }

        // Cast duration
        if (isset($data['duration']) && $data['duration'] !== null) {
            $d = (int)$data['duration'];
            if ($d > 0) {
                $data['duration'] = $d;
            } else {
                unset($data['duration']);
            }
        }

        return $data;
    }

    /**
     * Convenience method used by cron (older code).
     * @return array<string,mixed>|null
     */
    public static function findByMediaId(int $channelId, string $mediaId): ?array
    {
        return self::findByChannelAndMedia($channelId, $mediaId);
    }

    /** @param array<string,mixed> $data */
    public static function create(array $data): int
    {
        $channelId = (int)($data['channel_id'] ?? 0);
        $mediaId = (string)($data['media_id'] ?? '');
        $titleRaw = (string)($data['title_raw'] ?? ($data['title'] ?? ''));
        $publishDate = $data['publish_date'] ?? null;
        $publishDate = is_string($publishDate) ? $publishDate : null;

        $row = self::upsert($channelId, $mediaId, $publishDate, $titleRaw, $data);
        return (int)($row['id'] ?? 0);
    }

    /** @return array<int,array<string,mixed>> */
    public static function search(array $filters, int $page = 1, int $perPage = 20): array
    {
        $pdo = self::pdo();
        $page = max(1, $page);
        $perPage = max(1, min(100, $perPage));
        $offset = ($page - 1) * $perPage;

        $where = "1=1";
        $params = [];

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where .= " AND (title_raw LIKE :q OR title_clean LIKE :q OR media_id LIKE :q)";
            $params[':q'] = '%' . $q . '%';
        }

        if (!empty($filters['status'])) {
            $where .= " AND status = :st";
            $params[':st'] = (string)$filters['status'];
        }

        if (!empty($filters['channel_id'])) {
            $where .= " AND channel_id = :cid";
            $params[':cid'] = (int)$filters['channel_id'];
        }

        if (!empty($filters['category_id'])) {
            $where .= " AND category_id = :cat";
            $params[':cat'] = (int)$filters['category_id'];
        }

        if (!empty($filters['subcategory_id'])) {
            $where .= " AND subcategory_id = :sub";
            $params[':sub'] = (int)$filters['subcategory_id'];
        }

        $select = 'v.*';
        // Common derived/aliased columns
        if (self::has('last_ingested_at')) {
            $select .= ', v.last_ingested_at AS ingested_at';
        }

        // Sorting (whitelisted)
        $sort = (string)($filters['sort'] ?? 'publish_desc');
        $pushEmptyPublishLast = "(v.publish_date IS NULL OR v.publish_date = '') ASC";

        $order = match ($sort) {
            'publish_asc'   => $pushEmptyPublishLast . ', v.publish_date ASC, v.id ASC',
            'publish_desc'  => $pushEmptyPublishLast . ', v.publish_date DESC, v.id DESC',
            'ingested_asc'  => self::has('last_ingested_at') ? 'v.last_ingested_at ASC, v.id ASC' : 'v.id ASC',
            'ingested_desc' => self::has('last_ingested_at') ? 'v.last_ingested_at DESC, v.id DESC' : 'v.id DESC',
            'id_asc'        => 'v.id ASC',
            default         => 'v.id DESC',
        };

        $sql = "SELECT {$select},
                       c.name AS channel_name,
                       tc.name AS category_name,
                       ts.name AS subcategory_name
                FROM videos v
                LEFT JOIN channels c ON c.id = v.channel_id
                LEFT JOIN taxonomy tc ON tc.id = v.category_id
                LEFT JOIN taxonomy ts ON ts.id = v.subcategory_id
                WHERE {$where}
                ORDER BY {$order}
                LIMIT :limit OFFSET :offset";

        $st = $pdo->prepare($sql);
        foreach ($params as $k => $v) {
            $st->bindValue($k, $v);
        }
        $st->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $st->bindValue(':offset', $offset, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function count(array $filters): int
    {
        $pdo = self::pdo();
        $where = "1=1";
        $params = [];

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $where .= " AND (title_raw LIKE :q OR title_clean LIKE :q OR media_id LIKE :q)";
            $params[':q'] = '%' . $q . '%';
        }

        foreach (['status' => 'st', 'channel_id' => 'cid', 'category_id' => 'cat', 'subcategory_id' => 'sub'] as $f => $p) {
            if (!empty($filters[$f])) {
                $where .= " AND {$f} = :{$p}";
                $params[":{$p}"] = is_numeric((string)$filters[$f]) ? (int)$filters[$f] : (string)$filters[$f];
            }
        }

        $st = $pdo->prepare("SELECT COUNT(*) AS c FROM videos WHERE {$where}");
        foreach ($params as $k => $v) {
            $st->bindValue($k, $v);
        }
        $st->execute();
        return (int)($st->fetch(PDO::FETCH_ASSOC)['c'] ?? 0);
    }

    /** @return array<int,array{id:int,title_raw:string,channel_id:int,publish_date:?string}> */
    public static function listForProcessing(int $limit = 200): array
    {
        $limit = max(1, min(1000, $limit));
        $sql = "SELECT id, title_raw, channel_id, publish_date
                FROM videos
                WHERE (last_processed_at IS NULL OR last_processed_at = '')
                  AND status <> 'manual'
                ORDER BY last_ingested_at DESC, id DESC
                LIMIT :l";
        $st = self::pdo()->prepare($sql);
        $st->bindValue(':l', $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** @param array<string,mixed> $fields */
    public static function markProcessed(int $id, array $fields): void
    {
        $pdo = self::pdo();
        $updates = ["last_processed_at=:p", "last_error=NULL"];
        $bind = [
            ':p' => date('Y-m-d H:i:s'),
            ':id' => $id,
        ];

        $map = [
            'title_clean' => 'title_clean',
            'category_id' => 'category_id',
            'subcategory_id' => 'subcategory_id',
            'show_id' => 'show_id',
            'country_id' => 'country_id',
            'confidence' => 'confidence',
            'status' => 'status',
        ];

        foreach ($map as $k => $col) {
            if (!isset($fields[$k]) || !self::has($col)) {
                continue;
            }
            $ph = ':' . $k;
            $updates[] = "{$col}={$ph}";
            $bind[$ph] = $fields[$k];
        }

        $sql = "UPDATE videos SET " . implode(', ', $updates) . " WHERE id=:id";
        $pdo->prepare($sql)->execute($bind);
    }

    /**
     * @return array<int,int> list of video IDs
     */
    public static function listIdsForBackfill(int $limit = 200, string $mode = 'missing_subcategory'): array
    {
        $pdo = self::pdo();
        $limit = max(1, min(2000, (int)$limit));

        if ($mode === 'missing_any') {
            $sql = "SELECT id FROM videos WHERE status != 'manual' AND (category_id IS NULL OR subcategory_id IS NULL) ORDER BY publish_date DESC, id DESC LIMIT :lim";
        } else {
            $sql = "SELECT id FROM videos WHERE status != 'manual' AND category_id IS NOT NULL AND subcategory_id IS NULL ORDER BY publish_date DESC, id DESC LIMIT :lim";
        }

        $st = $pdo->prepare($sql);
        $st->bindValue(':lim', $limit, PDO::PARAM_INT);
        $st->execute();
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $out[] = (int)$r['id'];
        }
        return $out;
    }

    public static function markNeedsReview(int $id, string $message): void
    {
        $pdo = self::pdo();
        $sql = "UPDATE videos SET status='needs_review'";

        $bind = [':id' => $id];

        if (self::has('last_error')) {
            $sql .= ", last_error=:m";
            $bind[':m'] = $message;
        }

        $sql .= " WHERE id=:id";
        $pdo->prepare($sql)->execute($bind);
    }

    /**
     * Update ingested fields for an existing video row.
     *
     * Flexible signature to match older/newer callers:
     *   updateIngest($id, $titleRaw, $publishDate = null, $extra = [])
     *   updateIngest($id, ['title_raw'=>..., 'publish_date'=>..., 'video_url'=>...])
     */
    public static function updateIngest(...$args): void
    {
        $id = $args[0] ?? null;
        if (!is_int($id) && !(is_string($id) && ctype_digit($id))) {
            throw new \InvalidArgumentException('updateIngest: missing/invalid id');
        }
        $id = (int)$id;

        $data = [];
        if (isset($args[1]) && is_array($args[1])) {
            $data = $args[1];
        } else {
            if (isset($args[1]) && is_string($args[1])) $data['title_raw'] = $args[1];
            if (isset($args[2]) && (is_string($args[2]) || is_null($args[2]))) $data['publish_date'] = $args[2];
            if (isset($args[3]) && is_array($args[3])) $data = array_merge($data, $args[3]);
        }

        // Always touch last_ingested_at
        $data['last_ingested_at'] = (new \DateTimeImmutable('now'))->format('Y-m-d H:i:s');

        // Null-out last_error if the caller didn't explicitly set it
        if (!array_key_exists('last_error', $data)) {
            $data['last_error'] = null;
        }

        // Get PDO from existing helpers if available, else fallback to sqlite path.
        $pdo = null;
        if (method_exists(__CLASS__, 'pdo')) {
            /** @phpstan-ignore-next-line */
            $pdo = self::pdo();
        } elseif (class_exists(\App\Models\Entity::class) && method_exists(\App\Models\Entity::class, 'pdo')) {
            /** @phpstan-ignore-next-line */
            $pdo = \App\Models\Entity::pdo();
        } else {
            $db = getenv('KEYWORDS_DB_PATH') ?: (__DIR__ . '/../../storage/app.db');
            $pdo = new \PDO('sqlite:' . $db);
            $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        }

        // Detect existing columns to avoid "no such column" fatals.
        $cols = [];
        $st = $pdo->query("PRAGMA table_info(videos)");
        foreach ($st->fetchAll(\PDO::FETCH_ASSOC) as $r) {
            if (!empty($r['name'])) $cols[(string)$r['name']] = true;
        }

        // Accept both 'url' and 'video_url' keys; map to existing column.
        if (isset($data['url']) && !isset($data['video_url'])) {
            $data['video_url'] = $data['url'];
        }

        $set = [];
        $bind = [':id' => $id];
        foreach ($data as $k => $v) {
            if (!isset($cols[$k])) continue;
            $ph = ':' . $k;
            $set[] = "$k = $ph";
            $bind[$ph] = $v;
        }

        if (!$set) return;

        $sql = "UPDATE videos SET " . implode(', ', $set) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($bind);
    }


    /**
     * Update processing fields for an existing video row.
     *
     * Flexible signature:
     *   updateProcessing($id, $status = null, $confidence = null, $categoryId = null, $subcategoryId = null, $extra = [])
     *   updateProcessing($id, ['status'=>..., 'confidence'=>..., 'category_id'=>..., ...])
     */
    public static function updateProcessing(...$args): void
    {
        $id = $args[0] ?? null;
        if (!is_int($id) && !(is_string($id) && ctype_digit($id))) {
            throw new \InvalidArgumentException('updateProcessing: missing/invalid id');
        }
        $id = (int)$id;

        $data = [];
        if (isset($args[1]) && is_array($args[1])) {
            $data = $args[1];
        } else {
            if (isset($args[1]) && $args[1] !== null) $data['status'] = (string)$args[1];
            if (isset($args[2]) && $args[2] !== null) $data['confidence'] = (float)$args[2];
            if (isset($args[3]) && $args[3] !== null) $data['category_id'] = (int)$args[3];
            if (isset($args[4]) && $args[4] !== null) $data['subcategory_id'] = (int)$args[4];
            if (isset($args[5]) && is_array($args[5])) $data = array_merge($data, $args[5]);
        }

        // Always touch last_processed_at
        $data['last_processed_at'] = (new \DateTimeImmutable('now'))->format('Y-m-d H:i:s');

        // Get PDO
        $pdo = null;
        if (method_exists(__CLASS__, 'pdo')) {
            /** @phpstan-ignore-next-line */
            $pdo = self::pdo();
        } elseif (class_exists(\App\Models\Entity::class) && method_exists(\App\Models\Entity::class, 'pdo')) {
            /** @phpstan-ignore-next-line */
            $pdo = \App\Models\Entity::pdo();
        } else {
            $db = getenv('KEYWORDS_DB_PATH') ?: (__DIR__ . '/../../storage/app.db');
            $pdo = new \PDO('sqlite:' . $db);
            $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        }

        // Detect columns
        $cols = [];
        $st = $pdo->query("PRAGMA table_info(videos)");
        foreach ($st->fetchAll(\PDO::FETCH_ASSOC) as $r) {
            if (!empty($r['name'])) $cols[(string)$r['name']] = true;
        }

        // Null-out last_error if processing succeeded and caller didn't set it
        if (!array_key_exists('last_error', $data)) {
            $data['last_error'] = null;
        }

        $set = [];
        $bind = [':id' => $id];
        foreach ($data as $k => $v) {
            if (!isset($cols[$k])) continue;
            $ph = ':' . $k;
            $set[] = "$k = $ph";
            $bind[$ph] = $v;
        }

        if (!$set) return;

        $sql = "UPDATE videos SET " . implode(', ', $set) . " WHERE id = :id";
        $pdo->prepare($sql)->execute($bind);
    }

}
