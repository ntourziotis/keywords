<?php

declare(strict_types=1);

namespace App\Models;

final class VideoEntity extends BaseModel
{
    public static function replaceForVideo(int $videoId, string $role, array $entityIds): void
    {
        $pdo = self::pdo();
        $del = $pdo->prepare('DELETE FROM video_entities WHERE video_id=:v AND role=:r');
        $del->execute([':v' => $videoId, ':r' => $role]);

        if (empty($entityIds)) {
            return;
        }

        $ins = $pdo->prepare('INSERT OR IGNORE INTO video_entities (video_id, entity_id, role) VALUES (:v, :e, :r)');
        foreach ($entityIds as $id) {
            $ins->execute([':v' => $videoId, ':e' => (int)$id, ':r' => $role]);
        }
    }

    public static function listTermsForVideo(int $videoId, string $role): array
    {
        $stmt = self::pdo()->prepare(
            'SELECT e.name FROM video_entities ve JOIN entities e ON e.id=ve.entity_id WHERE ve.video_id=:v AND ve.role=:r ORDER BY e.name ASC'
        );
        $stmt->execute([':v' => $videoId, ':r' => $role]);
        return array_map(fn($r) => (string)$r['name'], $stmt->fetchAll());
    }
}
