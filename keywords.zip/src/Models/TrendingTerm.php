<?php

declare(strict_types=1);

namespace App\Models;

final class TrendingTerm extends BaseModel
{
    public static function top(string $scopeType = 'global', ?int $scopeId = null, int $windowHours = 24, int $limit = 15): array
    {
        $sql = 'SELECT term, count, computed_at FROM trending_terms WHERE scope_type=:s AND window_hours=:w';
        $params = [':s' => $scopeType, ':w' => $windowHours];
        if ($scopeId !== null) {
            $sql .= ' AND scope_id=:i';
            $params[':i'] = $scopeId;
        } else {
            $sql .= ' AND scope_id IS NULL';
        }
        $sql .= ' ORDER BY count DESC LIMIT :limit';

        $stmt = self::pdo()->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * @param array<int, array{term:string,count:int}> $terms
     */
    public static function replaceScope(string $scopeType, ?int $scopeId, int $windowHours, array $terms): void
    {
        $pdo = self::pdo();
        if ($scopeId === null) {
            $del = $pdo->prepare('DELETE FROM trending_terms WHERE scope_type=:s AND scope_id IS NULL AND window_hours=:w');
            $del->execute([':s' => $scopeType, ':w' => $windowHours]);
        } else {
            $del = $pdo->prepare('DELETE FROM trending_terms WHERE scope_type=:s AND scope_id=:i AND window_hours=:w');
            $del->execute([':s' => $scopeType, ':i' => $scopeId, ':w' => $windowHours]);
        }

        $ins = $pdo->prepare('INSERT INTO trending_terms (scope_type, scope_id, term, normalized_term, count, window_hours, computed_at) VALUES (:s, :i, :t, :n, :c, :w, :a)');
        $now = date('Y-m-d H:i:s');
        foreach ($terms as $t) {
            $term = trim((string)$t['term']);
            if ($term === '') {
                continue;
            }
            $ins->execute([
                ':s' => $scopeType,
                ':i' => $scopeId,
                ':t' => $term,
                ':n' => self::normalize($term),
                ':c' => (int)$t['count'],
                ':w' => $windowHours,
                ':a' => $now,
            ]);
        }
    }

    public static function normalize(string $s): string
    {
        $s = mb_strtolower(trim($s));
        $s = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $s);
        $s = preg_replace('/\s+/u', ' ', $s);
        return trim($s);
    }
}
