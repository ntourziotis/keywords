<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\DB;
use PDO;

final class TaxonomyRule
{
    private static function pdo(): PDO
    {
        return DB::pdo();
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    public static function all(?bool $onlyActive = null): array
    {
        $where = '';
        $params = [];
        if ($onlyActive === true) {
            $where = 'WHERE r.active = 1';
        } elseif ($onlyActive === false) {
            $where = 'WHERE r.active = 0';
        }



    /**
     * Paginated list of rules (for UI).
     *
     * @return array{rows: array<int,array<string,mixed>>, total:int, page:int, pages:int, per_page:int}
     */
    public static function paginate(?bool $onlyActive, int $page, int $per): array
    {
        $page = max(1, $page);

        $allowed = [25, 50, 100];
        if (!in_array($per, $allowed, true)) {
            $per = 50;
        }

        $where = '';
        $params = [];
        if ($onlyActive === true) {
            $where = 'WHERE r.active = 1';
        } elseif ($onlyActive === false) {
            $where = 'WHERE r.active = 0';
        }

        $pdo = self::pdo();

        $st = $pdo->prepare("SELECT COUNT(*) AS c FROM taxonomy_rules r {$where}");
        $st->execute($params);
        $total = (int)(($st->fetch(PDO::FETCH_ASSOC)['c'] ?? 0));

        $pages = max(1, (int)ceil($total / $per));
        if ($page > $pages) { $page = $pages; }

        $offset = ($page - 1) * $per;

        $sql = "SELECT r.*, tc.name AS category_name, ts.name AS subcategory_name
                FROM taxonomy_rules r
                LEFT JOIN taxonomy tc ON tc.id = r.category_id
                LEFT JOIN taxonomy ts ON ts.id = r.subcategory_id
                {$where}
                ORDER BY r.active DESC, r.priority DESC, r.id DESC
                LIMIT :limit OFFSET :offset";

        $st = $pdo->prepare($sql);
        $st->bindValue(':limit', $per, PDO::PARAM_INT);
        $st->bindValue(':offset', $offset, PDO::PARAM_INT);
        $st->execute($params);

        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'per_page' => $per,
        ];
    }

        $sql = "SELECT r.*, tc.name AS category_name, ts.name AS subcategory_name
                FROM taxonomy_rules r
                LEFT JOIN taxonomy tc ON tc.id = r.category_id
                LEFT JOIN taxonomy ts ON ts.id = r.subcategory_id
                {$where}
                ORDER BY r.active DESC, r.priority DESC, r.id DESC";

        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function find(int $id): ?array
    {
        $st = self::pdo()->prepare('SELECT * FROM taxonomy_rules WHERE id = :id LIMIT 1');
        $st->execute([':id' => $id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Create rule.
     *
     * @param array<string,mixed> $data
     */
    public static function create(array $data): int
    {
        $pdo = self::pdo();
        $sql = 'INSERT INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source, created_at, updated_at)
                VALUES (:name,:match_type,:pattern,:category_id,:subcategory_id,:confidence,:priority,:active,:source,datetime(\'now\'),datetime(\'now\'))';
        $st = $pdo->prepare($sql);
        $st->execute([
            ':name' => (string)($data['name'] ?? ''),
            ':match_type' => (string)($data['match_type'] ?? 'regex'),
            ':pattern' => (string)($data['pattern'] ?? ''),
            ':category_id' => $data['category_id'] !== null ? (int)$data['category_id'] : null,
            ':subcategory_id' => $data['subcategory_id'] !== null ? (int)$data['subcategory_id'] : null,
            ':confidence' => isset($data['confidence']) ? (float)$data['confidence'] : 0.70,
            ':priority' => isset($data['priority']) ? (int)$data['priority'] : 100,
            ':active' => isset($data['active']) ? (int)$data['active'] : 1,
            ':source' => (string)($data['source'] ?? 'manual'),
        ]);

        return (int)$pdo->lastInsertId();
    }

    /**
     * @param array<string,mixed> $data
     */
    public static function update(int $id, array $data): void
    {
        $allowed = ['name','match_type','pattern','category_id','subcategory_id','confidence','priority','active','source'];
        $set = [];
        $bind = [':id' => $id];
        foreach ($allowed as $k) {
            if (!array_key_exists($k, $data)) {
                continue;
            }
            $set[] = "$k = :$k";
            $bind[":$k"] = $data[$k];
        }
        $set[] = 'updated_at = datetime(\'now\')';

        $sql = 'UPDATE taxonomy_rules SET ' . implode(', ', $set) . ' WHERE id = :id';
        self::pdo()->prepare($sql)->execute($bind);
    }

    public static function delete(int $id): void
    {
        self::pdo()->prepare('DELETE FROM taxonomy_rules WHERE id = :id')->execute([':id' => $id]);
    }

    /**
     * Return best matching rule for a normalized title.
     *
     * @return array{rule:?array<string,mixed>,category_id:?int,subcategory_id:?int,confidence:float,matched_text:?string}
     */

    /**
     * Score all matching rules and return best (category, subcategory) plus confidence.
     *
     * This is a "pseudo-ML" approach: multiple weak signals can beat a single weak rule.
     * Confidence is computed from the separation between top and second-best scores.
     *
     * @return array{category_id:?int, subcategory_id:?int, confidence:float, breakdown:array<string,mixed>}
     */
    public static function scoreMatch(string $normalizedTitle): array
    {
        $rules = self::all(true);

        $catScores = [];      // catId => float
        $subScores = [];      // subId => float
        $subToCat = [];       // subId => catId
        $hits = [];           // debugging

        foreach ($rules as $r) {
            $pattern = (string)($r['pattern'] ?? '');
            if ($pattern === '') continue;

            $matchType = (string)($r['match_type'] ?? 'regex');
            $hit = false;

            if ($matchType === 'contains') {
                $needle = $pattern;
                $hit = ($needle !== '' && str_contains($normalizedTitle, $needle));
            } elseif ($matchType === 'starts_with') {
                $needle = $pattern;
                $hit = ($needle !== '' && str_starts_with($normalizedTitle, $needle));
            } elseif ($matchType === 'ends_with') {
                $needle = $pattern;
                $hit = ($needle !== '' && str_ends_with($normalizedTitle, $needle));
            } else { // regex
                $re = $pattern;
                // be tolerant: add delimiters if missing
                if ($re !== '' && $re[0] !== '/') {
                    $re = '/' . str_replace('/', '\/', $re) . '/u';
                }
                $hit = (@preg_match($re, $normalizedTitle) === 1);
            }

            if (!$hit) continue;

            $conf = (float)($r['confidence'] ?? 0.70);
            $weight = (int)($r['priority'] ?? 10); // treat "priority" as rule strength/weight
            if ($weight < 1) $weight = 1;
            if ($weight > 100) $weight = 100;

            $score = $conf * (float)$weight;

            $cat = isset($r['category_id']) ? (int)$r['category_id'] : 0;
            $sub = isset($r['subcategory_id']) ? (int)$r['subcategory_id'] : 0;

            if ($sub > 0) {
                // Derive category from parent if missing
                if ($cat <= 0) {
                    $parent = Taxonomy::parentIdOf($sub);
                    if ($parent) $cat = (int)$parent;
                }
                if ($cat > 0) {
                    $subToCat[$sub] = $cat;
                    $subScores[$sub] = ($subScores[$sub] ?? 0.0) + $score;
                    $catScores[$cat] = ($catScores[$cat] ?? 0.0) + ($score * 0.75);
                } else {
                    // subcategory without parent: still score sub
                    $subScores[$sub] = ($subScores[$sub] ?? 0.0) + $score;
                }
            } elseif ($cat > 0) {
                $catScores[$cat] = ($catScores[$cat] ?? 0.0) + $score;
            }

            $hits[] = [
                'id' => (int)($r['id'] ?? 0),
                'name' => (string)($r['name'] ?? ''),
                'match_type' => $matchType,
                'pattern' => $pattern,
                'category_id' => $cat ?: null,
                'subcategory_id' => $sub ?: null,
                'score' => $score,
            ];
        }

        // Pick best category
        arsort($catScores);
        $bestCat = key($catScores);
        $bestCatScore = $bestCat ? (float)$catScores[$bestCat] : 0.0;
        $secondCatScore = 0.0;
        if (count($catScores) > 1) {
            $vals = array_values($catScores);
            $secondCatScore = (float)$vals[1];
        }

        $categoryConfidence = 0.0;
        if ($bestCatScore > 0.0) {
            $categoryConfidence = $bestCatScore / max($bestCatScore + $secondCatScore, 1e-9);
        }

        $bestSub = null;
        $subConfidence = 0.0;
        if ($bestCat) {
            // Filter subScores for chosen category
            $subForCat = [];
            foreach ($subScores as $sid => $sc) {
                if (($subToCat[$sid] ?? null) === (int)$bestCat) {
                    $subForCat[(int)$sid] = (float)$sc;
                }
            }
            arsort($subForCat);
            $bestSub = key($subForCat);
            $bestSubScore = $bestSub ? (float)$subForCat[$bestSub] : 0.0;
            $secondSubScore = 0.0;
            if (count($subForCat) > 1) {
                $vals = array_values($subForCat);
                $secondSubScore = (float)$vals[1];
            }
            if ($bestSubScore > 0.0) {
                $subConfidence = $bestSubScore / max($bestSubScore + $secondSubScore, 1e-9);
            }
        }

        $overall = $categoryConfidence;
        if ($bestSub) {
            $overall = min(0.99, ($categoryConfidence * 0.60) + ($subConfidence * 0.40));
        }

        return [
            'category_id' => $bestCat ? (int)$bestCat : null,
            'subcategory_id' => $bestSub ? (int)$bestSub : null,
            'confidence' => (float)$overall,
            'breakdown' => [
                'category_scores' => $catScores,
                'subcategory_scores' => $subScores,
                'hits' => $hits,
                'category_confidence' => $categoryConfidence,
                'subcategory_confidence' => $subConfidence,
            ],
        ];
    }


    public static function bestMatch(string $normalizedTitle): array
    {
        $scored = self::scoreMatch($normalizedTitle);
        $cat = $scored['category_id'] ?? null;
        $sub = $scored['subcategory_id'] ?? null;
        $conf = (float)($scored['confidence'] ?? 0.0);

        return [
            'rule' => null,
            'category_id' => $cat,
            'subcategory_id' => $sub,
            'confidence' => $conf,
            'matched_text' => null,
            'breakdown' => $scored['breakdown'] ?? [],
        ];
    }
}
