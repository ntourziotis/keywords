PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  source_type TEXT NOT NULL DEFAULT 'mrss',
  source_url TEXT NOT NULL,
  is_news INTEGER NOT NULL DEFAULT 1,
  poll_every_seconds INTEGER NOT NULL DEFAULT 60,
  active INTEGER NOT NULL DEFAULT 1,
  last_poll_at TEXT NULL,
  last_poll_status TEXT NULL,
  last_poll_message TEXT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS taxonomy (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  parent_id INTEGER NULL,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  UNIQUE(type, parent_id, name)
);

-- SQLite UNIQUE treats NULLs as distinct, so root taxonomy (parent_id NULL) can duplicate.
-- Enforce uniqueness using an expression index.
CREATE UNIQUE INDEX IF NOT EXISTS idx_taxonomy_unique_expr ON taxonomy(type, COALESCE(parent_id,0), name);

CREATE TABLE IF NOT EXISTS stopwords (
  word TEXT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS errors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT,
  message TEXT,
  context TEXT,
  route TEXT,
  url TEXT,
  video_id INTEGER,
  channel_id INTEGER,
  level INTEGER,
  is_resolved INTEGER DEFAULT 0,
  created_at TEXT,
  updated_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_errors_created_at ON errors(created_at);
CREATE INDEX IF NOT EXISTS idx_errors_video_id ON errors(video_id);


CREATE TABLE IF NOT EXISTS videos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL,
  media_id TEXT NOT NULL,
  publish_date TEXT NULL,
  title_raw TEXT NOT NULL,
  title_clean TEXT NULL,
  status TEXT NOT NULL DEFAULT 'auto',
  category_id INTEGER NULL,
  subcategory_id INTEGER NULL,
  show_id INTEGER NULL,
  country_id INTEGER NULL,
  confidence REAL NOT NULL DEFAULT 0,
  last_error TEXT,
  last_ingested_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_processed_at TEXT NULL,
  FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE,
  FOREIGN KEY(category_id) REFERENCES taxonomy(id) ON DELETE SET NULL,
  FOREIGN KEY(subcategory_id) REFERENCES taxonomy(id) ON DELETE SET NULL,
  FOREIGN KEY(show_id) REFERENCES taxonomy(id) ON DELETE SET NULL,
  FOREIGN KEY(country_id) REFERENCES taxonomy(id) ON DELETE SET NULL,
  UNIQUE(channel_id, media_id)
);

-- Rules-based taxonomy classifier
CREATE TABLE IF NOT EXISTS taxonomy_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  match_type TEXT NOT NULL DEFAULT 'regex',
  pattern TEXT NOT NULL,
  category_id INTEGER NULL,
  subcategory_id INTEGER NULL,
  confidence REAL NOT NULL DEFAULT 0.70,
  priority INTEGER NOT NULL DEFAULT 100,
  active INTEGER NOT NULL DEFAULT 1,
  source TEXT NOT NULL DEFAULT 'seed',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NULL,
  FOREIGN KEY(category_id) REFERENCES taxonomy(id) ON DELETE SET NULL,
  FOREIGN KEY(subcategory_id) REFERENCES taxonomy(id) ON DELETE SET NULL,
  UNIQUE(match_type, pattern, category_id, subcategory_id)
);

CREATE INDEX IF NOT EXISTS idx_taxonomy_rules_active_priority ON taxonomy_rules(active, priority DESC);
CREATE INDEX IF NOT EXISTS idx_taxonomy_rules_category ON taxonomy_rules(category_id);
CREATE INDEX IF NOT EXISTS idx_taxonomy_rules_subcategory ON taxonomy_rules(subcategory_id);

CREATE TABLE IF NOT EXISTS entities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  name TEXT NOT NULL,
  normalized_name TEXT NOT NULL,
  UNIQUE(type, normalized_name)
);

CREATE TABLE IF NOT EXISTS entity_aliases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_id INTEGER NOT NULL,
  alias TEXT NOT NULL,
  normalized_alias TEXT NOT NULL,
  FOREIGN KEY(entity_id) REFERENCES entities(id) ON DELETE CASCADE,
  UNIQUE(entity_id, normalized_alias)
);

CREATE TABLE IF NOT EXISTS video_entities (
  video_id INTEGER NOT NULL,
  entity_id INTEGER NOT NULL,
  role TEXT NOT NULL,
  PRIMARY KEY(video_id, entity_id, role),
  FOREIGN KEY(video_id) REFERENCES videos(id) ON DELETE CASCADE,
  FOREIGN KEY(entity_id) REFERENCES entities(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  term TEXT NOT NULL,
  normalized_term TEXT NOT NULL,
  occurrences INTEGER NOT NULL DEFAULT 1,
  example_title TEXT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(type, normalized_term)
);

CREATE TABLE IF NOT EXISTS trending_terms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope_type TEXT NOT NULL DEFAULT 'global',
  scope_id INTEGER NULL,
  term TEXT NOT NULL,
  normalized_term TEXT NOT NULL,
  count INTEGER NOT NULL,
  window_hours INTEGER NOT NULL DEFAULT 24,
  computed_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(scope_type, scope_id, normalized_term, window_hours)
);

CREATE TABLE IF NOT EXISTS ingest_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT NULL,
  items_seen INTEGER NOT NULL DEFAULT 0,
  items_new INTEGER NOT NULL DEFAULT 0,
  items_updated INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'ok',
  message TEXT NULL,
  FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS error_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  context TEXT NOT NULL,
  ref_id TEXT NULL,
  message TEXT NOT NULL,
  trace TEXT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  resolved INTEGER NOT NULL DEFAULT 0
);

-- Seed taxonomy (categories + countries placeholders)
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort) VALUES
('category', NULL, 'News', 10),
('category', NULL, 'Sports', 20),
('category', NULL, 'Entertainment', 30),
('category', NULL, 'Lifestyle', 40),
('category', NULL, 'Gossip', 50),
('category', NULL, 'Fashion', 60),
('category', NULL, 'Woman', 70),
('category', NULL, 'Man', 80),
('category', NULL, 'Kids', 90),
('category', NULL, 'Travel', 100),
('category', NULL, 'Health', 110),
('category', NULL, 'Automoto', 120),
('category', NULL, 'Gaming', 130);

-- Seed basic subcategories (MVP)
-- NEWS
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Politics - Government', 10 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Politics - Opposition', 20 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Parliament / Βουλή', 30 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Police / Crime', 40 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Justice / Courts', 50 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Accidents / Tragedy', 60 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Economy / Prices', 70 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Weather', 80 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Natural Disasters', 90 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'International / Geopolitics', 100 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Society', 110 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Education', 120 FROM taxonomy WHERE type='category' AND name='News';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Transport / Strikes', 130 FROM taxonomy WHERE type='category' AND name='News';

-- SPORTS
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Football - Super League', 10 FROM taxonomy WHERE type='category' AND name='Sports';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Football - Europe', 20 FROM taxonomy WHERE type='category' AND name='Sports';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Basket - EuroLeague', 30 FROM taxonomy WHERE type='category' AND name='Sports';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Basket - Greece', 40 FROM taxonomy WHERE type='category' AND name='Sports';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Transfers', 50 FROM taxonomy WHERE type='category' AND name='Sports';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'NBA', 60 FROM taxonomy WHERE type='category' AND name='Sports';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'F1 / Motorsports', 70 FROM taxonomy WHERE type='category' AND name='Sports';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Tennis', 80 FROM taxonomy WHERE type='category' AND name='Sports';

-- ENTERTAINMENT
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'TV / Reality', 10 FROM taxonomy WHERE type='category' AND name='Entertainment';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'TV / Shows', 20 FROM taxonomy WHERE type='category' AND name='Entertainment';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Music', 30 FROM taxonomy WHERE type='category' AND name='Entertainment';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Cinema / Series', 40 FROM taxonomy WHERE type='category' AND name='Entertainment';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Viral / Social', 50 FROM taxonomy WHERE type='category' AND name='Entertainment';

-- LIFESTYLE
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Food / Recipes', 10 FROM taxonomy WHERE type='category' AND name='Lifestyle';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Beauty', 20 FROM taxonomy WHERE type='category' AND name='Lifestyle';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Fitness', 30 FROM taxonomy WHERE type='category' AND name='Lifestyle';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Wellness', 40 FROM taxonomy WHERE type='category' AND name='Lifestyle';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Home / Decor', 50 FROM taxonomy WHERE type='category' AND name='Lifestyle';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Relationships', 60 FROM taxonomy WHERE type='category' AND name='Lifestyle';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Astrology', 70 FROM taxonomy WHERE type='category' AND name='Lifestyle';

-- GOSSIP
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Relationships / Breakups', 10 FROM taxonomy WHERE type='category' AND name='Gossip';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Scandals', 20 FROM taxonomy WHERE type='category' AND name='Gossip';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'TV Gossip', 30 FROM taxonomy WHERE type='category' AND name='Gossip';

-- FASHION
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Trends', 10 FROM taxonomy WHERE type='category' AND name='Fashion';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Red Carpet Looks', 20 FROM taxonomy WHERE type='category' AND name='Fashion';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Shopping / Finds', 30 FROM taxonomy WHERE type='category' AND name='Fashion';

-- WOMAN
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Women\'s Health', 10 FROM taxonomy WHERE type='category' AND name='Woman';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Pregnancy / Motherhood', 20 FROM taxonomy WHERE type='category' AND name='Woman';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Psychology', 30 FROM taxonomy WHERE type='category' AND name='Woman';

-- MAN
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Men\'s Health', 10 FROM taxonomy WHERE type='category' AND name='Man';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Style', 20 FROM taxonomy WHERE type='category' AND name='Man';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Gadgets', 30 FROM taxonomy WHERE type='category' AND name='Man';

-- KIDS
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Parenting', 10 FROM taxonomy WHERE type='category' AND name='Kids';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Activities', 20 FROM taxonomy WHERE type='category' AND name='Kids';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Kids Health', 30 FROM taxonomy WHERE type='category' AND name='Kids';

-- TRAVEL
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Greek Islands', 10 FROM taxonomy WHERE type='category' AND name='Travel';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Europe', 20 FROM taxonomy WHERE type='category' AND name='Travel';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'City Breaks', 30 FROM taxonomy WHERE type='category' AND name='Travel';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Travel Tips', 40 FROM taxonomy WHERE type='category' AND name='Travel';

-- HEALTH
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Symptoms / Conditions', 10 FROM taxonomy WHERE type='category' AND name='Health';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Nutrition', 20 FROM taxonomy WHERE type='category' AND name='Health';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Mental Health', 30 FROM taxonomy WHERE type='category' AND name='Health';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Doctor Tips', 40 FROM taxonomy WHERE type='category' AND name='Health';

-- AUTOMOTO
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Car News', 10 FROM taxonomy WHERE type='category' AND name='Automoto';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Tests / Reviews', 20 FROM taxonomy WHERE type='category' AND name='Automoto';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Electric / Hybrid', 30 FROM taxonomy WHERE type='category' AND name='Automoto';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Moto', 40 FROM taxonomy WHERE type='category' AND name='Automoto';

-- GAMING
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Releases', 10 FROM taxonomy WHERE type='category' AND name='Gaming';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Reviews', 20 FROM taxonomy WHERE type='category' AND name='Gaming';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'Esports', 30 FROM taxonomy WHERE type='category' AND name='Gaming';
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'subcategory', id, 'PlayStation', 40 FROM taxonomy WHERE type='category' AND name='Gaming';

-- Seed taxonomy rules (starter packs)
-- NOTE: rules operate on normalized lowercase titles (greek tonos stripped). You can freely translate taxonomy names later; IDs stay stable.

-- NEWS
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'News: Weather', 'regex', '(καιρο[ςσ]|κακοκαιρ|βροχ|καταιγιδ|χιον|θερμοκρασι|ανεμ|χαλαζ)', c.id, s.id, 0.92, 950, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Weather'
WHERE c.type='category' AND c.name='News';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'News: Natural Disasters', 'regex', '(σεισμ|πυρκαγι|φωτια|πλημμυρ|καυσωνα|ανεμοστρ|καταιγιδα)', c.id, s.id, 0.90, 940, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Natural Disasters'
WHERE c.type='category' AND c.name='News';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'News: Police/Crime', 'regex', '(ελ\.?ασ|αστυνομ|συλληψ|ληστ|δολοφον|φον|εγκλημ|βιασ|μαχαιρ|πυροβολ)', c.id, s.id, 0.86, 930, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Police / Crime'
WHERE c.type='category' AND c.name='News';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'News: Parliament', 'regex', '(βουλη|ολομελει|επιτροπ|τροπολογ|ψηφοφορ|νομοσχεδι)', c.id, s.id, 0.82, 920, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Parliament / Βουλή'
WHERE c.type='category' AND c.name='News';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'News: Economy/Prices', 'regex', '(οικονομ|ακριβε|τιμ[εη]ς|πληθωρισ|μισθ|συνταξ|φορο|ρευμα|καυσιμ|αγορ|τραπεζ|χρηματιστηρ)', c.id, s.id, 0.78, 910, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Economy / Prices'
WHERE c.type='category' AND c.name='News';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'News: International', 'regex', '(ουκραν|ρωσ(ια|ος)|ισραηλ|γαζ|ηπα|trump|biden|eu\b|εε\b|nato|τουρκ|συρι|ιραν|κινα)', c.id, s.id, 0.72, 900, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='International / Geopolitics'
WHERE c.type='category' AND c.name='News';

-- SPORTS
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Sports: Football Greece', 'regex', '(super\s*league|σουπερ\s*λιγκ|ποδοσφαιρ|γκολ|var\b|διαιτητ|προπονητ|αεκ\b|παοκ\b|ολυμπιακ|παναθηναικ)', c.id, s.id, 0.80, 880, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Football - Super League'
WHERE c.type='category' AND c.name='Sports';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Sports: Football Europe', 'regex', '(champions\s*league|europa\s*league|conference\s*league|uefa\b|ucl\b|uel\b|uecl\b)', c.id, s.id, 0.82, 870, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Football - Europe'
WHERE c.type='category' AND c.name='Sports';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Sports: EuroLeague', 'regex', '(euroleague|ευρωλιγκ|ευρωλιγκα|panathinaikos|olympiacos)', c.id, s.id, 0.78, 860, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Basket - EuroLeague'
WHERE c.type='category' AND c.name='Sports';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Sports: NBA', 'regex', '(nba\b|lebron|curry|lakers|warriors|bucks|giannis|αντετοκουνμπο)', c.id, s.id, 0.82, 850, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='NBA'
WHERE c.type='category' AND c.name='Sports';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Sports: Transfers', 'regex', '(μεταγραφ|transfer\b|signed\b|deal\b|ανακοινωθ)', c.id, s.id, 0.74, 840, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Transfers'
WHERE c.type='category' AND c.name='Sports';

-- ENTERTAINMENT
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Ent: Reality', 'regex', '(big\s*brother|survivor|masterchef|my\s*style\s*rocks|gntm|the\s*voice|ρι[αά]λιτι|αποχωρησ|nomination)', c.id, s.id, 0.88, 830, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='TV / Reality'
WHERE c.type='category' AND c.name='Entertainment';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Ent: Shows', 'regex', '(εκπομπ[ηη]ς|παρουσιαστ|τηλεθεασ|πρεμιερ|καλεσμεν|στο\s*πλατο|happy\s*day)', c.id, s.id, 0.78, 820, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='TV / Shows'
WHERE c.type='category' AND c.name='Entertainment';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Ent: Music', 'regex', '(τραγουδ|album\b|single\b|spotify|concert\b|συναυλι)', c.id, s.id, 0.72, 810, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Music'
WHERE c.type='category' AND c.name='Entertainment';

-- GAMING
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Gaming: PlayStation', 'regex', '(playstation|ps5\b|ps4\b|sony\b)', c.id, s.id, 0.82, 780, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='PlayStation'
WHERE c.type='category' AND c.name='Gaming';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Gaming: Esports', 'regex', '(esports|e-sports|fortnite|league\s*of\s*legends|valorant|cs2\b|counter\s*strike)', c.id, s.id, 0.78, 770, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Esports'
WHERE c.type='category' AND c.name='Gaming';

-- AUTOMOTO
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Automoto: Moto', 'regex', '(μοτο\b|μοτοσυκλετ|μηχαν[ηη]|scooter\b|yamaha\b|honda\b)', c.id, s.id, 0.78, 760, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Moto'
WHERE c.type='category' AND c.name='Automoto';

INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Automoto: Electric', 'regex', '(electric\b|ev\b|hybrid\b|ηλεκτρικ|υβριδ)', c.id, s.id, 0.76, 750, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Electric / Hybrid'
WHERE c.type='category' AND c.name='Automoto';

-- HEALTH
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Health: Mental', 'regex', '(αγχο[ςσ]|καταθλιψ|ψυχολογ|burnout|πανικ|stress\b)', c.id, s.id, 0.76, 740, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Mental Health'
WHERE c.type='category' AND c.name='Health';

-- TRAVEL
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Travel: Greek Islands', 'regex', '(santorini|σαντοριν|mykonos|μυκον|naxos|ναξ|paros|παρο|crete|κρητ|rhodes|ροδο)', c.id, s.id, 0.80, 730, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Greek Islands'
WHERE c.type='category' AND c.name='Travel';

-- LIFESTYLE quick wins
INSERT OR IGNORE INTO taxonomy_rules (name, match_type, pattern, category_id, subcategory_id, confidence, priority, active, source)
SELECT 'Lifestyle: Astrology', 'regex', '(ζωδι|horoscope|αστρολογ)', c.id, s.id, 0.78, 720, 1, 'seed'
FROM taxonomy c JOIN taxonomy s ON s.type='subcategory' AND s.parent_id=c.id AND s.name='Astrology'
WHERE c.type='category' AND c.name='Lifestyle';


INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'show', NULL, 'Ειδήσεις', 10 WHERE NOT EXISTS (SELECT 1 FROM taxonomy WHERE type='show' AND name='Ειδήσεις');
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'show', NULL, 'Super League', 20 WHERE NOT EXISTS (SELECT 1 FROM taxonomy WHERE type='show' AND name='Super League');
INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort)
SELECT 'show', NULL, 'Ligue1', 30 WHERE NOT EXISTS (SELECT 1 FROM taxonomy WHERE type='show' AND name='Ligue1');

INSERT OR IGNORE INTO taxonomy (type, parent_id, name, sort) VALUES
('country', NULL, 'Ελλάδα', 10),
('country', NULL, 'Γαλλία', 20),
('country', NULL, 'ΗΠΑ', 30),
('country', NULL, 'Ηνωμένο Βασίλειο', 40);