<?php
declare(strict_types=1);

// Convenience front-controller for servers without rewrite rules.
// Allows links like /videos?page=2 to work.
require __DIR__ . '/../app.php';
