<?php
declare(strict_types=1);

namespace SelfCron;

final class Jobs
{
    public static function runAll(?string $dbPath): array
    {
        $started = microtime(true);

        $root = realpath(__DIR__ . '/../../');
        if (!$root) {
            return ['status' => 'error', 'error' => 'Project root not found'];
        }

        // Prefer real CLI php binary if you can set it in env
        // e.g. PHP_CLI=/usr/bin/php
        $php = getenv('PHP_CLI') ?: 'php';

        $cron = $root . '/bin/cron.php';
        if (!is_file($cron)) {
            return ['status' => 'error', 'error' => 'bin/cron.php not found', 'cron' => $cron];
        }

        // Run as separate process so:
        // - CLI-only checks pass
        // - exit() inside cron won't kill the dashboard request
        $cmd = escapeshellcmd($php) . ' ' . escapeshellarg($cron) . ' 2>&1';

        // Some hostings disable shell_exec. We'll detect it.
        if (!function_exists('shell_exec')) {
            return ['status' => 'error', 'error' => 'shell_exec disabled on hosting. Need exec/proc_open or include-mode.'];
        }

        $out = (string)shell_exec($cmd);

        return [
            'status' => 'ok',
            'dbPath' => $dbPath,
            'jobs' => [['job' => 'bin/cron.php (cli)', 'status' => 'ok']],
            'cmd' => $cmd,
            'output' => $out,
            'duration_ms' => (int)round((microtime(true) - $started) * 1000),
        ];
    }
}
