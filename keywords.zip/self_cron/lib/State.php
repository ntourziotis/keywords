<?php
declare(strict_types=1);

namespace SelfCron;

final class State
{
    private string $file;
    private array $data = [];

    public function __construct(string $file)
    {
        $this->file = $file;
        if (is_file($file)) {
            $json = file_get_contents($file);
            $decoded = json_decode((string)$json, true);
            if (is_array($decoded)) $this->data = $decoded;
        }
    }

    public function get(string $key)
    {
        return $this->data[$key] ?? null;
    }

    public function set(string $key, $value): void
    {
        $this->data[$key] = $value;
        $this->persist();
    }

    private function persist(): void
    {
        $tmp = $this->file . '.tmp';
        file_put_contents($tmp, json_encode($this->data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        @rename($tmp, $this->file);
    }
}
