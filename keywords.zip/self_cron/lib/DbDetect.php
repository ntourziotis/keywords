<?php
declare(strict_types=1);

namespace SelfCron;

final class DbDetect
{
    public static function detectSqlitePath(): ?string
{
    // Hard-set (stable)
    $hard = '/home/www/adweb4/adweb.gr/keywords/storage/app.db';
    if (is_file($hard) && filesize($hard) > 0) return $hard;

    // Optional env override
    $env = getenv('KEYWORDS_DB_PATH');
    if ($env && is_file($env) && filesize($env) > 0) return $env;

    return null;
}

	
}
