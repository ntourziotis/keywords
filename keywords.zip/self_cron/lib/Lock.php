<?php
declare(strict_types=1);

namespace SelfCron;

final class Lock
{
    private string $path;
    private $fp = null;

    public function __construct(string $path)
    {
        $this->path = $path;
        @mkdir(dirname($path), 0775, true);
    }

    public function acquireNonBlocking(): bool
    {
        $this->fp = fopen($this->path, 'c+');
        if (!$this->fp) return false;
        return flock($this->fp, LOCK_EX | LOCK_NB);
    }

    public function acquireBlocking(int $timeoutSeconds): bool
    {
        $this->fp = fopen($this->path, 'c+');
        if (!$this->fp) return false;

        $start = time();
        while (true) {
            if (flock($this->fp, LOCK_EX | LOCK_NB)) return true;
            if ((time() - $start) >= $timeoutSeconds) return false;
            usleep(200000); // 200ms
        }
    }

    public function release(): void
    {
        if ($this->fp) {
            @flock($this->fp, LOCK_UN);
            @fclose($this->fp);
            $this->fp = null;
        }
    }
}
