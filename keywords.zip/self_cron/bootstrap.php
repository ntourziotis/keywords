<?php
declare(strict_types=1);

namespace SelfCron;

require_once __DIR__ . '/lib/State.php';
require_once __DIR__ . '/lib/Lock.php';
require_once __DIR__ . '/lib/DbDetect.php';
require_once __DIR__ . '/lib/Jobs.php';

final class Bootstrap
{
    // κάθε πόσα δευτερόλεπτα να επιτρέπεται run
    public const TICK_MIN_SECONDS = 60;

    public static function tick(): void
    {
        if (getenv('KEYWORDS_SELFCRON_DISABLED') === '1') return;

        $stateFile = __DIR__ . '/../storage/self_cron_state.json';
        $lockFile  = __DIR__ . '/../storage/self_cron.lock';

        @mkdir(dirname($stateFile), 0775, true);

        $lock = new Lock($lockFile);
        if (!$lock->acquireNonBlocking()) return; // τρέχει ήδη αλλού

        try {
            $state = new State($stateFile);
            $lastRun = (int)($state->get('last_run_ts') ?? 0);
            $now = time();

            if (($now - $lastRun) < self::TICK_MIN_SECONDS) return;

            // mark early (anti-thundering herd)
            $state->set('last_run_ts', $now);
            $state->set('last_run_human', date('c', $now));
            $state->set('last_result', 'running');

            $dbPath = DbDetect::detectSqlitePath();
            $result = Jobs::runAll($dbPath);

            $state->set('last_result', $result['status'] ?? 'ok');
            $state->set('last_details', $result);
        } catch (\Throwable $e) {
            try {
                $state = isset($state) ? $state : new State($stateFile);
                $state->set('last_result', 'error');
                $state->set('last_error', [
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]);
            } catch (\Throwable $ignored) {}
        } finally {
            $lock->release();
        }
    }

    // Manual run (bypass interval)
    public static function runNow(): array
    {
        $stateFile = __DIR__ . '/../storage/self_cron_state.json';
        $lockFile  = __DIR__ . '/../storage/self_cron.lock';
        @mkdir(dirname($stateFile), 0775, true);

        $lock = new Lock($lockFile);
        if (!$lock->acquireBlocking(10)) {
            return ['status' => 'busy', 'message' => 'Another run is in progress'];
        }

        try {
            $state = new State($stateFile);
            $now = time();
            $state->set('last_run_ts', $now);
            $state->set('last_run_human', date('c', $now));
            $state->set('last_result', 'running');

            $dbPath = DbDetect::detectSqlitePath();
            $result = Jobs::runAll($dbPath);

            $state->set('last_result', $result['status'] ?? 'ok');
            $state->set('last_details', $result);

            return $result;
        } catch (\Throwable $e) {
            return ['status' => 'error', 'error' => $e->getMessage()];
        } finally {
            $lock->release();
        }
    }

    public static function requireCronKeyOrDie(): void
    {
        $expected = getenv('KEYWORDS_CRON_KEY') ?: 'kalimera';
        $given = $_GET['key'] ?? '';
        if (!hash_equals((string)$expected, (string)$given)) {
            http_response_code(403);
            header('Content-Type: text/plain; charset=utf-8');
            echo "Forbidden";
            exit;
        }
    }
}
